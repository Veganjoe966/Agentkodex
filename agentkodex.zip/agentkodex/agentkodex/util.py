from __future__ import annotations

import datetime as _dt
import json
import os
import re
import secrets
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable

SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|token|secret|password|passwd|pwd|authorization)(\s*[:=]\s*)([^\s'\"]+)") ,
    re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._\-+/=]{12,}"),
    re.compile(r"(?i)(sk-[A-Za-z0-9]{16,})"),
]


def now_utc_iso() -> str:
    return _dt.datetime.now(_dt.UTC).replace(microsecond=0).isoformat()


def make_run_id(prefix: str = "run") -> str:
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"{stamp}-{prefix}-{secrets.token_hex(3)}"


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_text(path: Path, default: str = "") -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return default
    except UnicodeDecodeError:
        return default


def write_text(path: Path, text: str) -> None:
    ensure_dir(path.parent)
    path.write_text(text, encoding="utf-8")


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default
    except json.JSONDecodeError:
        return default


def write_json(path: Path, data: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def shlex_join(parts: Iterable[str]) -> str:
    return shlex.join(list(parts))


def split_command(command: str) -> list[str]:
    return shlex.split(command)


def run_command(command: str | list[str], cwd: Path, timeout: int = 900, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    if isinstance(command, str):
        shell = True
        cmd = command
    else:
        shell = False
        cmd = command
    return subprocess.run(
        cmd,
        cwd=str(cwd),
        env=env,
        shell=shell,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def git_available(cwd: Path) -> bool:
    result = subprocess.run(["git", "rev-parse", "--is-inside-work-tree"], cwd=str(cwd), capture_output=True, text=True)
    return result.returncode == 0 and result.stdout.strip() == "true"


def get_git_diff(cwd: Path) -> str:
    if not git_available(cwd):
        return ""
    result = subprocess.run(["git", "diff", "--no-ext-diff"], cwd=str(cwd), capture_output=True, text=True)
    return result.stdout if result.returncode == 0 else result.stdout + result.stderr


def get_changed_files(cwd: Path) -> list[str]:
    if not git_available(cwd):
        return []
    result = subprocess.run(["git", "status", "--porcelain"], cwd=str(cwd), capture_output=True, text=True)
    files: list[str] = []
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            files.append(line[3:].strip())
    return files


def redact_secrets(text: str) -> str:
    redacted = text
    for pattern in SECRET_PATTERNS:
        def _replace(match: re.Match[str]) -> str:
            if len(match.groups()) >= 3:
                return f"{match.group(1)}{match.group(2)}[REDACTED]"
            if len(match.groups()) >= 1:
                return f"{match.group(1)}[REDACTED]"
            return "[REDACTED]"
        redacted = pattern.sub(_replace, redacted)
    return redacted


def truncate_middle(text: str, max_chars: int) -> str:
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    keep = max_chars // 2
    return text[:keep] + "\n...[truncated]...\n" + text[-keep:]


def supports_color() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def bold(text: str) -> str:
    return f"\033[1m{text}\033[0m" if supports_color() else text


def green(text: str) -> str:
    return f"\033[32m{text}\033[0m" if supports_color() else text


def yellow(text: str) -> str:
    return f"\033[33m{text}\033[0m" if supports_color() else text


def red(text: str) -> str:
    return f"\033[31m{text}\033[0m" if supports_color() else text


def emit_yaml(data: Any, indent: int = 0) -> str:
    """Small dependency-free YAML emitter for Agentkodex-generated config."""
    spaces = " " * indent
    if data is None:
        return "null"
    if isinstance(data, bool):
        return "true" if data else "false"
    if isinstance(data, (int, float)):
        return str(data)
    if isinstance(data, str):
        if data == "" or any(ch in data for ch in ":#\n{}[]&*?|-<>=!%@`\"") or data.strip() != data:
            return json.dumps(data)
        return data
    if isinstance(data, list):
        if not data:
            return "[]"
        lines = []
        for item in data:
            if isinstance(item, (dict, list)):
                rendered = emit_yaml(item, indent + 2)
                lines.append(f"{spaces}- {rendered.lstrip() if '\n' not in rendered else ''}")
                if "\n" in rendered:
                    lines.append(rendered)
            else:
                lines.append(f"{spaces}- {emit_yaml(item, 0)}")
        return "\n".join(lines)
    if isinstance(data, dict):
        if not data:
            return "{}"
        lines = []
        for key, value in data.items():
            key_s = str(key)
            if isinstance(value, (dict, list)) and value:
                lines.append(f"{spaces}{key_s}:")
                lines.append(emit_yaml(value, indent + 2))
            else:
                lines.append(f"{spaces}{key_s}: {emit_yaml(value, 0)}")
        return "\n".join(lines)
    return json.dumps(str(data))


def human_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{int(minutes)}m {sec:.0f}s"
    hours, minutes = divmod(minutes, 60)
    return f"{int(hours)}h {int(minutes)}m"
