from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path
from typing import Any

from .adapters import get_adapter
from .discovery import discover_project
from .gates import resolve_gates, run_quality_gates, score_gates
from .kodex import KodexStore
from .models import DiscoveryResult, RunContext, RunResult
from .policy import PolicyEngine, load_policy
from .prompts import build_mission_prompt
from .planner import generate_plan
from .pty_runner import PtySession
from .security import simple_security_review
from .util import get_changed_files, get_git_diff, make_run_id, read_text, write_json, write_text


def init_repo(repo: Path, force: bool = False) -> None:
    store = KodexStore(repo)
    store.init(force=force)


def discover_and_write(repo: Path) -> DiscoveryResult:
    discovery = discover_project(repo)
    KodexStore(repo).write_discovery(discovery)
    return discovery


def run_agent(context: RunContext, stream: bool = False) -> RunResult:
    store = KodexStore(context.repo)
    store.init(force=False)
    discovery = discover_project(context.repo)
    store.write_discovery(discovery)
    policy = PolicyEngine(load_policy(context.repo))
    adapter = get_adapter(context.agent_id)
    plan = generate_plan(context.task, discovery, context.gates if context.gates != ["auto"] else None)
    prompt = build_mission_prompt(context, discovery, store.read_project_markdown()) + "\n\n" + plan
    store.write_run_start(context, prompt)
    write_text(context.run_dir / "plan.md", plan)

    # Launch adapter through a real PTY.
    command = adapter.build_command(context)
    launch_str = " ".join(command)
    store.append_command_log(context.run_dir, launch_str, risk="agent_session")
    exit_code: int | None = None
    output = ""
    status = "running"
    message = ""
    try:
        pty_session = PtySession(command, cwd=context.repo)
        stdin_text = adapter.prepare_stdin(prompt, context)
        exit_code, output = pty_session.run(
            stdin_text=stdin_text,
            idle_timeout=context.idle_timeout,
            hard_timeout=context.timeout,
            max_output_chars=context.max_output_chars,
            stream=stream,
        )
        store.append_transcript(context.run_dir, output)
        status = "passed" if exit_code == 0 else "failed"
        message = f"Adapter process exited with code {exit_code}."
    except Exception as exc:  # noqa: BLE001
        status = "error"
        message = f"Agentkodex failed to launch/run adapter: {exc}"
        store.append_transcript(context.run_dir, f"\n[Agentkodex error] {message}\n")

    gate_pairs = resolve_gates(discovery, context.gates)
    gate_results = run_quality_gates(context.repo, gate_pairs, policy, context.mode, context.yes, timeout=context.timeout) if gate_pairs else []
    for gate in gate_results:
        store.append_command_log(context.run_dir, gate.command, exit_code=gate.exit_code, risk="quality_gate")
        gate_dir = context.run_dir / "gates"
        gate_dir.mkdir(parents=True, exist_ok=True)
        safe_name = gate.name.replace("/", "_").replace(" ", "_")
        write_text(gate_dir / f"{safe_name}.stdout.txt", gate.stdout)
        write_text(gate_dir / f"{safe_name}.stderr.txt", gate.stderr)

    changed_files = get_changed_files(context.repo)
    diff = get_git_diff(context.repo)
    security_report = simple_security_review(diff, read_text(context.run_dir / "commands.log"))
    score = score_gates(gate_results, changed_files, exit_code)

    if gate_results and any(not gate.passed for gate in gate_results):
        status = "failed"
        failed = ", ".join(g.name for g in gate_results if not g.passed)
        message += f" Quality gates failed: {failed}."
    elif gate_results and all(gate.passed for gate in gate_results) and status != "error":
        status = "passed"
        message += " All quality gates passed."
    elif not gate_results and status == "passed":
        message += " No quality gates discovered or requested."

    result = RunResult(
        run_id=context.run_id,
        status=status,  # type: ignore[arg-type]
        agent_id=context.agent_id,
        repo=str(context.repo),
        run_dir=str(context.run_dir),
        message=message.strip(),
        gates=gate_results,
        changed_files=changed_files,
        score=score,
    )
    store.write_summary(result, diff, security_report)
    return result


def make_context(repo: Path, task: str, agent_id: str, mode: str, yes: bool = False, gates: list[str] | None = None, custom_command: str | None = None, shell_command: str | None = None, project_cli: str | None = None, timeout: int = 900, idle_timeout: int = 20, run_id: str | None = None) -> RunContext:
    repo = repo.resolve()
    store = KodexStore(repo)
    store.init(force=False)
    rid = run_id or make_run_id(agent_id)
    run_dir = store.create_run_dir(rid)
    return RunContext(
        repo=repo,
        task=task,
        agent_id=agent_id,
        mode=mode,  # type: ignore[arg-type]
        run_id=rid,
        run_dir=run_dir,
        yes=yes,
        gates=gates or ["auto"],
        custom_command=custom_command,
        shell_command=shell_command,
        project_cli=project_cli,
        timeout=timeout,
        idle_timeout=idle_timeout,
    )


def _copy_repo_for_tournament(src: Path, dst: Path) -> None:
    ignore_names = {".git", ".agentkodex", "node_modules", ".venv", "venv", "dist", "build", ".next", "target", "__pycache__"}
    def ignore(_dir: str, names: list[str]) -> set[str]:
        return {name for name in names if name in ignore_names}
    shutil.copytree(src, dst, ignore=ignore)


def run_tournament(repo: Path, task: str, agents: list[str], mode: str, yes: bool, gates: list[str] | None, custom_commands: dict[str, str] | None = None, timeout: int = 900, idle_timeout: int = 20, stream: bool = False) -> dict[str, Any]:
    repo = repo.resolve()
    parent_store = KodexStore(repo)
    parent_store.init(force=False)
    run_id = make_run_id("tournament")
    run_dir = parent_store.create_run_dir(run_id)
    results: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="agentkodex-tournament-") as tmp:
        tmp_path = Path(tmp)
        for agent_id in agents:
            workspace = tmp_path / agent_id
            _copy_repo_for_tournament(repo, workspace)
            context = make_context(
                workspace,
                task,
                agent_id,
                mode,
                yes=yes,
                gates=gates,
                custom_command=(custom_commands or {}).get(agent_id),
                timeout=timeout,
                idle_timeout=idle_timeout,
            )
            result = run_agent(context, stream=stream)
            # Copy child run artifacts into parent run directory.
            dest = run_dir / agent_id
            shutil.copytree(context.run_dir, dest, dirs_exist_ok=True)
            results.append(result.to_dict())
    winner = max(results, key=lambda r: r.get("score", 0.0)) if results else None
    payload = {
        "run_id": run_id,
        "task": task,
        "agents": agents,
        "results": results,
        "winner": winner,
    }
    write_json(run_dir / "tournament.json", payload)
    lines = [f"# Agentkodex Tournament {run_id}", "", f"Task: {task}", ""]
    if winner:
        lines.append(f"Winner: `{winner['agent_id']}` score `{winner['score']}` status `{winner['status']}`")
    lines.extend(["", "## Results", ""])
    for r in results:
        lines.append(f"- `{r['agent_id']}` status={r['status']} score={r['score']} changed_files={len(r.get('changed_files', []))}")
    write_text(run_dir / "summary.md", "\n".join(lines) + "\n")
    return payload
