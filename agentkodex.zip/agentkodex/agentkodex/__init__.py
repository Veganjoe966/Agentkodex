"""Agentkodex: CLI-native agent harness for autonomous software delivery."""

__version__ = "0.1.0"
