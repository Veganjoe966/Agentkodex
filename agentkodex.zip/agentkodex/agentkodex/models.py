from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Literal

Mode = Literal["observe", "supervised", "sandbox-auto", "trusted-auto"]
CommandRisk = Literal["safe", "approval_required", "blocked"]
RunStatus = Literal["created", "running", "passed", "failed", "blocked", "error"]


@dataclass(slots=True)
class CommandSpec:
    name: str
    command: str
    source: str
    confidence: str = "medium"
    required: bool = False


@dataclass(slots=True)
class DiscoveryResult:
    repo: str
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    package_managers: list[str] = field(default_factory=list)
    commands: dict[str, CommandSpec] = field(default_factory=dict)
    package_scripts: dict[str, str] = field(default_factory=dict)
    env_files: list[str] = field(default_factory=list)
    service_files: list[str] = field(default_factory=list)
    ci_files: list[str] = field(default_factory=list)
    evidence: dict[str, str] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["commands"] = {k: asdict(v) for k, v in self.commands.items()}
        return data


@dataclass(slots=True)
class AgentCapabilities:
    interactive: bool = True
    supports_prompt_stdin: bool = True
    edits_files: bool = True
    runs_commands: bool = True
    notes: str = ""


@dataclass(slots=True)
class AgentAdapterInfo:
    id: str
    display_name: str
    executable: str | None
    installed: bool
    launch_command: list[str]
    capabilities: AgentCapabilities
    install_hint: str


@dataclass(slots=True)
class QualityGateResult:
    name: str
    command: str
    exit_code: int
    passed: bool
    duration_seconds: float
    stdout: str
    stderr: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class RunContext:
    repo: Path
    task: str
    agent_id: str
    mode: Mode
    run_id: str
    run_dir: Path
    yes: bool = False
    gates: list[str] = field(default_factory=list)
    custom_command: str | None = None
    shell_command: str | None = None
    project_cli: str | None = None
    timeout: int = 900
    idle_timeout: int = 20
    max_output_chars: int = 500_000


@dataclass(slots=True)
class RunResult:
    run_id: str
    status: RunStatus
    agent_id: str
    repo: str
    run_dir: str
    message: str
    gates: list[QualityGateResult] = field(default_factory=list)
    changed_files: list[str] = field(default_factory=list)
    score: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["gates"] = [gate.to_dict() for gate in self.gates]
        return data
