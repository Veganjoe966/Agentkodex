from __future__ import annotations

import errno
import os
import pty
import select
import signal
import subprocess
import time
from pathlib import Path

from .util import redact_secrets, truncate_middle


class PtyRunError(RuntimeError):
    pass


class PtySession:
    """Minimal persistent PTY wrapper for CLI agents.

    This deliberately uses Python's standard library instead of adding a pexpect
    dependency. It records raw terminal output and can feed an initial prompt.
    """

    def __init__(self, command: list[str], cwd: Path, env: dict[str, str] | None = None) -> None:
        self.command = command
        self.cwd = cwd
        self.env = env
        self.master_fd: int | None = None
        self.slave_fd: int | None = None
        self.process: subprocess.Popen[bytes] | None = None

    def start(self) -> None:
        self.master_fd, self.slave_fd = pty.openpty()
        env = os.environ.copy()
        if self.env:
            env.update(self.env)
        env.setdefault("TERM", "xterm-256color")
        self.process = subprocess.Popen(
            self.command,
            cwd=str(self.cwd),
            env=env,
            stdin=self.slave_fd,
            stdout=self.slave_fd,
            stderr=self.slave_fd,
            preexec_fn=os.setsid if hasattr(os, "setsid") else None,
        )
        os.close(self.slave_fd)
        self.slave_fd = None

    def send(self, text: str) -> None:
        if self.master_fd is None:
            raise PtyRunError("PTY session has not started")
        if not text:
            return
        os.write(self.master_fd, text.encode("utf-8", errors="ignore"))

    def read_until_exit_or_idle(self, idle_timeout: int = 20, hard_timeout: int = 900, max_output_chars: int = 500_000, stream: bool = False) -> tuple[int | None, str]:
        if self.process is None or self.master_fd is None:
            raise PtyRunError("PTY session has not started")
        output_parts: list[str] = []
        start = time.monotonic()
        last_output = time.monotonic()
        exit_code: int | None = None
        while True:
            now = time.monotonic()
            if now - start > hard_timeout:
                self.terminate()
                output_parts.append("\n[Agentkodex] Hard timeout reached; process terminated.\n")
                exit_code = self.process.poll()
                break
            if self.process.poll() is not None:
                exit_code = self.process.returncode
                # Drain remaining output.
                drained = self._read_available()
                if drained:
                    output_parts.append(drained)
                    if stream:
                        print(redact_secrets(drained), end="", flush=True)
                break
            if now - last_output > idle_timeout:
                output_parts.append(f"\n[Agentkodex] Idle timeout reached after {idle_timeout}s. Leaving process state captured and terminating session.\n")
                self.terminate()
                exit_code = self.process.poll()
                break
            readable, _, _ = select.select([self.master_fd], [], [], 0.25)
            if readable:
                chunk = self._read_available()
                if chunk:
                    last_output = time.monotonic()
                    output_parts.append(chunk)
                    if stream:
                        print(redact_secrets(chunk), end="", flush=True)
                    if sum(len(p) for p in output_parts) > max_output_chars:
                        output_parts.append("\n[Agentkodex] Max output capture reached; terminating session.\n")
                        self.terminate()
                        exit_code = self.process.poll()
                        break
        output = "".join(output_parts)
        return exit_code, truncate_middle(redact_secrets(output), max_output_chars)

    def _read_available(self) -> str:
        if self.master_fd is None:
            return ""
        chunks: list[bytes] = []
        while True:
            try:
                readable, _, _ = select.select([self.master_fd], [], [], 0)
                if not readable:
                    break
                data = os.read(self.master_fd, 4096)
                if not data:
                    break
                chunks.append(data)
            except OSError as exc:
                if exc.errno in {errno.EIO, errno.EBADF}:
                    break
                raise
        return b"".join(chunks).decode("utf-8", errors="replace")

    def terminate(self) -> None:
        if self.process and self.process.poll() is None:
            try:
                if hasattr(os, "killpg"):
                    os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
                else:
                    self.process.terminate()
            except ProcessLookupError:
                pass
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    if hasattr(os, "killpg"):
                        os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
                    else:
                        self.process.kill()
                except ProcessLookupError:
                    pass
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None

    def run(self, stdin_text: str, idle_timeout: int, hard_timeout: int, max_output_chars: int, stream: bool = False) -> tuple[int | None, str]:
        self.start()
        # Give interactive CLIs a small moment to draw their prompt.
        time.sleep(0.5)
        initial = self._read_available()
        if stream and initial:
            print(redact_secrets(initial), end="", flush=True)
        if stdin_text:
            self.send(stdin_text)
        exit_code, output = self.read_until_exit_or_idle(idle_timeout, hard_timeout, max_output_chars, stream=stream)
        if initial:
            output = redact_secrets(initial) + output
        return exit_code, output
