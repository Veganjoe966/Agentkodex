from __future__ import annotations

from .models import DiscoveryResult


def suggest_agent(task: str, discovery: DiscoveryResult, installed: dict[str, bool] | None = None) -> dict[str, object]:
    """Deterministic local router for choosing an adapter.

    This does not call an LLM. It gives Agentkodex a transparent default router
    while still allowing users to override with --agent.
    """
    installed = installed or {}
    task_lower = task.lower()
    scores = {
        "claude-code": 65,
        "codex": 65,
        "aider": 55,
        "gemini": 55,
        "opencode": 50,
        "cursor": 50,
        "custom": 40,
        "shell": 20,
    }
    reasons: dict[str, list[str]] = {k: [] for k in scores}

    if any(word in task_lower for word in ["refactor", "migrate", "large", "architecture", "e2e", "end-to-end"]):
        scores["claude-code"] += 15
        scores["codex"] += 10
        reasons["claude-code"].append("Task appears broad/multi-file.")
        reasons["codex"].append("Task appears suitable for implementation and validation loops.")
    if any(word in task_lower for word in ["fix", "bug", "test", "failing", "error"]):
        scores["codex"] += 15
        scores["aider"] += 10
        reasons["codex"].append("Task is debugging/test-oriented.")
        reasons["aider"].append("Task may benefit from focused patch-oriented editing.")
    if any(word in task_lower for word in ["small", "copy", "readme", "docs", "typo"]):
        scores["aider"] += 10
        scores["shell"] += 5
        reasons["aider"].append("Task looks small and patch-focused.")
    if "python" in discovery.languages:
        scores["aider"] += 4
        reasons["aider"].append("Python project detected.")
    if "javascript/typescript" in discovery.languages or "typescript" in discovery.languages:
        scores["codex"] += 5
        scores["claude-code"] += 5
        reasons["codex"].append("JavaScript/TypeScript project detected.")
        reasons["claude-code"].append("JavaScript/TypeScript project detected.")
    for agent, is_installed in installed.items():
        if is_installed:
            scores[agent] = scores.get(agent, 0) + 30
            reasons.setdefault(agent, []).append("Adapter executable is installed.")
        else:
            scores[agent] = scores.get(agent, 0) - 20
            reasons.setdefault(agent, []).append("Adapter executable was not found on PATH.")

    ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    best = ranked[0][0]
    return {
        "recommended_agent": best,
        "ranked": [{"agent": agent, "score": score, "reasons": reasons.get(agent, [])} for agent, score in ranked],
    }


def generate_plan(task: str, discovery: DiscoveryResult, gates: list[str] | None = None) -> str:
    selected_gates = gates or [name for name in ["lint", "test", "build"] if name in discovery.commands]
    if selected_gates == ["auto"]:
        selected_gates = [name for name in ["lint", "test", "build"] if name in discovery.commands]
    lines = [
        "# Agentkodex Execution Plan",
        "",
        "## Goal",
        "",
        task,
        "",
        "## Project understanding",
        "",
        f"- Repository: `{discovery.repo}`",
        f"- Languages: {', '.join(discovery.languages) if discovery.languages else 'unknown'}",
        f"- Frameworks: {', '.join(discovery.frameworks) if discovery.frameworks else 'unknown'}",
        f"- Package managers: {', '.join(discovery.package_managers) if discovery.package_managers else 'unknown'}",
        "",
        "## Implementation phases",
        "",
        "1. Inspect current repo state with read-only commands.",
        "2. Identify files and tests directly related to the requested task.",
        "3. Make the smallest coherent implementation change.",
        "4. Run the narrowest relevant validation command.",
        "5. Repair failures using stderr/stdout and project conventions.",
        "6. Run required quality gates.",
        "7. Summarize changed files, command results, and remaining risks.",
        "",
        "## Discovered commands",
        "",
    ]
    if discovery.commands:
        for name, spec in sorted(discovery.commands.items()):
            lines.append(f"- `{name}`: `{spec.command}` from {spec.source} confidence={spec.confidence}")
    else:
        lines.append("- No commands discovered yet.")
    lines.extend(["", "## Required quality gates", ""])
    if selected_gates:
        for gate in selected_gates:
            command = discovery.commands[gate].command if gate in discovery.commands else gate
            lines.append(f"- `{gate}`: `{command}`")
    else:
        lines.append("- No gates discovered. The agent must explain how it validated the task.")
    lines.extend([
        "",
        "## Definition of done",
        "",
        "- Requested behavior is implemented.",
        "- Unrelated files are not changed.",
        "- Required quality gates pass or failures are honestly reported with logs.",
        "- The final summary includes files changed, commands run, tests passed/failed, and risks.",
        "",
    ])
    return "\n".join(lines)
