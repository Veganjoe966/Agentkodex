from __future__ import annotations

import re
from pathlib import Path

SECRET_DIFF_PATTERNS = [
    re.compile(r"^\+.*(?i:api[_-]?key|secret|password|token)\s*[:=]\s*['\"]?[^\s'\"]{8,}", re.MULTILINE),
    re.compile(r"^\+.*(?i:bearer\s+[A-Za-z0-9._\-+/=]{12,})", re.MULTILINE),
    re.compile(r"^\+.*sk-[A-Za-z0-9]{16,}", re.MULTILINE),
]

RISKY_DIFF_PATTERNS = [
    ("high", re.compile(r"^\+.*eval\(", re.MULTILINE), "New use of eval detected."),
    ("medium", re.compile(r"^\+.*innerHTML\s*=", re.MULTILINE), "New direct innerHTML assignment detected."),
    ("medium", re.compile(r"^\+.*shell=True", re.MULTILINE), "New Python shell=True usage detected."),
    ("high", re.compile(r"^\+.*process\.env\.[A-Z0-9_]*(SECRET|TOKEN|KEY)", re.MULTILINE), "New secret environment access; verify it is not logged or exposed."),
]


def simple_security_review(diff: str, command_log: str = "") -> str:
    findings: list[str] = []
    for pattern in SECRET_DIFF_PATTERNS:
        if pattern.search(diff):
            findings.append("- **critical**: Possible secret or credential added in diff. Review immediately before committing.")
            break
    for severity, pattern, message in RISKY_DIFF_PATTERNS:
        if pattern.search(diff):
            findings.append(f"- **{severity}**: {message}")
    if "sudo" in command_log:
        findings.append("- **high**: `sudo` appeared in command log. Confirm no host-level mutation occurred.")
    if "rm -rf" in command_log:
        findings.append("- **high**: `rm -rf` appeared in command log. Confirm no destructive cleanup affected important files.")
    if not findings:
        findings.append("- No obvious high-risk patterns detected by Agentkodex static review. This is not a substitute for a human security review.")
    return "# Security Review\n\n" + "\n".join(findings) + "\n"
