from __future__ import annotations

import json
import re
import tomllib
from pathlib import Path
from typing import Any

from .models import CommandSpec, DiscoveryResult
from .util import read_text

JS_FRAMEWORK_DEPS = {
    "next": "nextjs",
    "react": "react",
    "vue": "vue",
    "nuxt": "nuxt",
    "svelte": "svelte",
    "@sveltejs/kit": "sveltekit",
    "vite": "vite",
    "astro": "astro",
    "express": "express",
    "fastify": "fastify",
    "nestjs": "nestjs",
    "@nestjs/core": "nestjs",
    "remix": "remix",
    "@remix-run/node": "remix",
}

PY_FRAMEWORK_DEPS = {
    "django": "django",
    "flask": "flask",
    "fastapi": "fastapi",
    "litestar": "litestar",
    "pytest": "pytest",
    "ruff": "ruff",
}


def discover_project(repo: Path) -> DiscoveryResult:
    repo = repo.resolve()
    result = DiscoveryResult(repo=str(repo))
    _detect_common_files(repo, result)
    _detect_node(repo, result)
    _detect_python(repo, result)
    _detect_go(repo, result)
    _detect_rust(repo, result)
    _detect_ruby(repo, result)
    _detect_java(repo, result)
    _detect_dotnet(repo, result)
    _detect_make_and_task(repo, result)
    _detect_docker(repo, result)
    _detect_ci(repo, result)
    _infer_default_gates(result)
    _dedupe(result)
    if not result.commands:
        result.warnings.append("No project commands were discovered. Add scripts to package.json, Makefile, pyproject.toml, or CI files for stronger automation.")
    return result


def _add_unique(items: list[str], value: str) -> None:
    if value and value not in items:
        items.append(value)


def _add_command(result: DiscoveryResult, name: str, command: str, source: str, confidence: str = "medium", required: bool = False) -> None:
    if not command:
        return
    existing = result.commands.get(name)
    if existing and existing.confidence == "high":
        return
    result.commands[name] = CommandSpec(name=name, command=command, source=source, confidence=confidence, required=required)


def _detect_common_files(repo: Path, result: DiscoveryResult) -> None:
    for pattern in [".env.example", ".env.sample", ".env.local.example", "example.env"]:
        if (repo / pattern).exists():
            result.env_files.append(pattern)
    for filename in ["AGENTS.md", "CLAUDE.md", "README.md", "CONTRIBUTING.md"]:
        if (repo / filename).exists():
            result.evidence[filename] = f"Found {filename}"


def _load_package_json(path: Path) -> dict[str, Any] | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError):
        return None


def _detect_node(repo: Path, result: DiscoveryResult) -> None:
    package_json = repo / "package.json"
    pkg = _load_package_json(package_json)
    if not pkg:
        return
    _add_unique(result.languages, "javascript/typescript")
    result.evidence["package.json"] = "Found package.json"

    pm = "npm"
    if (repo / "pnpm-lock.yaml").exists():
        pm = "pnpm"
    elif (repo / "yarn.lock").exists():
        pm = "yarn"
    elif (repo / "bun.lockb").exists() or (repo / "bun.lock").exists():
        pm = "bun"
    elif isinstance(pkg.get("packageManager"), str):
        raw = pkg["packageManager"].split("@", 1)[0]
        if raw in {"npm", "pnpm", "yarn", "bun"}:
            pm = raw
    _add_unique(result.package_managers, pm)

    if pm == "pnpm":
        run_prefix = "pnpm"
        install_cmd = "pnpm install"
        add_cmd = "pnpm add"
    elif pm == "yarn":
        run_prefix = "yarn"
        install_cmd = "yarn install"
        add_cmd = "yarn add"
    elif pm == "bun":
        run_prefix = "bun run"
        install_cmd = "bun install"
        add_cmd = "bun add"
    else:
        run_prefix = "npm run"
        install_cmd = "npm install"
        add_cmd = "npm install"

    _add_command(result, "install", install_cmd, "package manager detection", "high")
    _add_command(result, "add_dependency", add_cmd, "package manager detection", "medium")

    scripts = pkg.get("scripts") if isinstance(pkg.get("scripts"), dict) else {}
    result.package_scripts.update({str(k): str(v) for k, v in scripts.items()})
    for script_name, script_value in scripts.items():
        command = f"{run_prefix} {script_name}" if pm != "yarn" or script_name not in {"start", "test"} else f"yarn {script_name}"
        canonical = _canonical_script_name(script_name)
        if canonical:
            _add_command(result, canonical, command, f"package.json scripts.{script_name}", "high", required=canonical in {"lint", "test", "build"})
        else:
            _add_command(result, f"script:{script_name}", command, f"package.json scripts.{script_name}", "medium")

    deps: dict[str, str] = {}
    for key in ["dependencies", "devDependencies", "peerDependencies"]:
        if isinstance(pkg.get(key), dict):
            deps.update(pkg[key])
    for dep in deps:
        framework = JS_FRAMEWORK_DEPS.get(dep)
        if framework:
            _add_unique(result.frameworks, framework)
    if any(path.exists() for path in [repo / "tsconfig.json", repo / "tsconfig.base.json"]):
        _add_unique(result.languages, "typescript")


def _canonical_script_name(script_name: str) -> str | None:
    normalized = script_name.lower().replace(":", "_").replace("-", "_")
    mapping = {
        "dev": "dev",
        "start": "start",
        "build": "build",
        "lint": "lint",
        "test": "test",
        "test_unit": "test",
        "unit": "test",
        "test_e2e": "e2e",
        "e2e": "e2e",
        "typecheck": "typecheck",
        "type_check": "typecheck",
        "format": "format",
        "check": "check",
        "db_migrate": "db_migrate",
        "migrate": "db_migrate",
        "db_seed": "db_seed",
        "seed": "db_seed",
    }
    return mapping.get(normalized)


def _detect_python(repo: Path, result: DiscoveryResult) -> None:
    pyproject = repo / "pyproject.toml"
    requirements = repo / "requirements.txt"
    has_python = pyproject.exists() or requirements.exists() or (repo / "Pipfile").exists() or (repo / "uv.lock").exists()
    if not has_python:
        return
    _add_unique(result.languages, "python")
    if (repo / "uv.lock").exists():
        _add_unique(result.package_managers, "uv")
        _add_command(result, "install", "uv sync", "uv.lock", "high")
    elif pyproject.exists():
        _add_unique(result.package_managers, "pip")
        _add_command(result, "install", "python -m pip install -e .", "pyproject.toml", "medium")
    elif requirements.exists():
        _add_unique(result.package_managers, "pip")
        _add_command(result, "install", "python -m pip install -r requirements.txt", "requirements.txt", "high")

    pydata: dict[str, Any] = {}
    if pyproject.exists():
        try:
            pydata = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        except (tomllib.TOMLDecodeError, UnicodeDecodeError):
            result.warnings.append("Could not parse pyproject.toml")
    deps_text = pyproject.read_text(encoding="utf-8", errors="ignore") if pyproject.exists() else ""
    if requirements.exists():
        deps_text += "\n" + requirements.read_text(encoding="utf-8", errors="ignore")
    lower_deps = deps_text.lower()
    for dep, framework in PY_FRAMEWORK_DEPS.items():
        if re.search(rf"\b{re.escape(dep)}\b", lower_deps):
            _add_unique(result.frameworks, framework)
    if "pytest" in lower_deps or (repo / "pytest.ini").exists():
        _add_command(result, "test", "python -m pytest", "pytest detection", "high", required=True)
    elif (repo / "tests").exists():
        _add_command(result, "test", "python -m unittest discover -s tests", "tests directory detection", "medium", required=True)
    if "ruff" in lower_deps:
        _add_command(result, "lint", "python -m ruff check .", "ruff detection", "high", required=True)
    if "mypy" in lower_deps:
        _add_command(result, "typecheck", "python -m mypy .", "mypy detection", "medium")
    tool = pydata.get("tool", {}) if isinstance(pydata.get("tool"), dict) else {}
    poe = tool.get("poetry", {}) if isinstance(tool.get("poetry"), dict) else {}
    if poe:
        _add_unique(result.package_managers, "poetry")
        _add_command(result, "install", "poetry install", "poetry config", "high")
        if not result.commands.get("test"):
            _add_command(result, "test", "poetry run pytest", "poetry config", "medium", required=True)


def _detect_go(repo: Path, result: DiscoveryResult) -> None:
    if not (repo / "go.mod").exists():
        return
    _add_unique(result.languages, "go")
    _add_unique(result.package_managers, "go")
    _add_command(result, "install", "go mod download", "go.mod", "high")
    _add_command(result, "test", "go test ./...", "go.mod", "high", required=True)
    _add_command(result, "build", "go build ./...", "go.mod", "high", required=True)
    _add_command(result, "lint", "go vet ./...", "go.mod", "medium", required=True)


def _detect_rust(repo: Path, result: DiscoveryResult) -> None:
    if not (repo / "Cargo.toml").exists():
        return
    _add_unique(result.languages, "rust")
    _add_unique(result.package_managers, "cargo")
    _add_command(result, "install", "cargo fetch", "Cargo.toml", "high")
    _add_command(result, "test", "cargo test", "Cargo.toml", "high", required=True)
    _add_command(result, "build", "cargo build", "Cargo.toml", "high", required=True)
    _add_command(result, "lint", "cargo clippy --all-targets --all-features", "Cargo.toml", "medium", required=True)
    _add_command(result, "format", "cargo fmt --check", "Cargo.toml", "medium")


def _detect_ruby(repo: Path, result: DiscoveryResult) -> None:
    if not (repo / "Gemfile").exists():
        return
    _add_unique(result.languages, "ruby")
    _add_unique(result.package_managers, "bundler")
    _add_command(result, "install", "bundle install", "Gemfile", "high")
    _add_command(result, "test", "bundle exec rake test", "Gemfile", "medium", required=True)
    _add_command(result, "build", "bundle exec rake", "Gemfile", "low")
    gemfile = read_text(repo / "Gemfile").lower()
    if "rails" in gemfile:
        _add_unique(result.frameworks, "rails")
        _add_command(result, "dev", "bin/rails server", "Gemfile rails detection", "medium")
        _add_command(result, "db_migrate", "bin/rails db:migrate", "Gemfile rails detection", "medium")


def _detect_java(repo: Path, result: DiscoveryResult) -> None:
    if (repo / "pom.xml").exists():
        _add_unique(result.languages, "java")
        _add_unique(result.package_managers, "maven")
        _add_command(result, "install", "mvn dependency:resolve", "pom.xml", "medium")
        _add_command(result, "test", "mvn test", "pom.xml", "high", required=True)
        _add_command(result, "build", "mvn package", "pom.xml", "high", required=True)
    if (repo / "build.gradle").exists() or (repo / "build.gradle.kts").exists():
        _add_unique(result.languages, "java/kotlin")
        _add_unique(result.package_managers, "gradle")
        gradle = "./gradlew" if (repo / "gradlew").exists() else "gradle"
        _add_command(result, "test", f"{gradle} test", "gradle build", "high", required=True)
        _add_command(result, "build", f"{gradle} build", "gradle build", "high", required=True)


def _detect_dotnet(repo: Path, result: DiscoveryResult) -> None:
    csproj_files = list(repo.glob("*.csproj")) + list(repo.glob("*/*.csproj"))
    sln_files = list(repo.glob("*.sln"))
    if not csproj_files and not sln_files:
        return
    _add_unique(result.languages, "csharp")
    _add_unique(result.package_managers, "dotnet")
    _add_command(result, "install", "dotnet restore", ".NET project detection", "high")
    _add_command(result, "test", "dotnet test", ".NET project detection", "high", required=True)
    _add_command(result, "build", "dotnet build", ".NET project detection", "high", required=True)


def _detect_make_and_task(repo: Path, result: DiscoveryResult) -> None:
    makefile = repo / "Makefile"
    if makefile.exists():
        result.service_files.append("Makefile")
        text = read_text(makefile)
        targets = re.findall(r"^([a-zA-Z0-9_.-]+):(?:\s|$)", text, re.MULTILINE)
        for target in targets:
            canonical = _canonical_script_name(target)
            if canonical:
                _add_command(result, canonical, f"make {target}", "Makefile", "medium", required=canonical in {"lint", "test", "build"})
            elif target in {"install", "setup", "ci"}:
                _add_command(result, target, f"make {target}", "Makefile", "medium")
    justfile = repo / "justfile"
    if justfile.exists():
        result.service_files.append("justfile")
        text = read_text(justfile)
        targets = re.findall(r"^([a-zA-Z0-9_.-]+):", text, re.MULTILINE)
        for target in targets:
            canonical = _canonical_script_name(target)
            if canonical:
                _add_command(result, canonical, f"just {target}", "justfile", "medium", required=canonical in {"lint", "test", "build"})
    taskfile = repo / "Taskfile.yml"
    if taskfile.exists() or (repo / "Taskfile.yaml").exists():
        result.service_files.append("Taskfile")
        _add_unique(result.package_managers, "task")
        for target in ["install", "dev", "build", "lint", "test", "e2e"]:
            _add_command(result, target, f"task {target}", "Taskfile detection", "low", required=target in {"lint", "test", "build"})


def _detect_docker(repo: Path, result: DiscoveryResult) -> None:
    for name in ["docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml"]:
        if (repo / name).exists():
            result.service_files.append(name)
            _add_command(result, "services_up", f"docker compose -f {name} up -d", name, "medium")
            _add_command(result, "services_down", f"docker compose -f {name} down", name, "medium")
            break
    if (repo / "Dockerfile").exists():
        result.service_files.append("Dockerfile")
        _add_command(result, "docker_build", "docker build .", "Dockerfile", "medium")


def _detect_ci(repo: Path, result: DiscoveryResult) -> None:
    gh = repo / ".github" / "workflows"
    if gh.exists():
        for workflow in gh.glob("*.yml"):
            result.ci_files.append(str(workflow.relative_to(repo)))
        for workflow in gh.glob("*.yaml"):
            result.ci_files.append(str(workflow.relative_to(repo)))


def _infer_default_gates(result: DiscoveryResult) -> None:
    for name in ["lint", "test", "build"]:
        if name in result.commands:
            result.commands[name].required = True


def _dedupe(result: DiscoveryResult) -> None:
    result.languages = sorted(set(result.languages))
    result.frameworks = sorted(set(result.frameworks))
    result.package_managers = sorted(set(result.package_managers))
    result.env_files = sorted(set(result.env_files))
    result.service_files = sorted(set(result.service_files))
    result.ci_files = sorted(set(result.ci_files))
