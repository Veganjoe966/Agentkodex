from __future__ import annotations

import os
import shlex
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from .models import AgentAdapterInfo, AgentCapabilities, RunContext


class Adapter(Protocol):
    id: str
    display_name: str

    def info(self, context: RunContext | None = None) -> AgentAdapterInfo: ...
    def build_command(self, context: RunContext) -> list[str]: ...
    def prepare_stdin(self, prompt: str, context: RunContext) -> str: ...


@dataclass(slots=True)
class GenericInteractiveAdapter:
    id: str
    display_name: str
    executable_candidates: list[str]
    default_args: list[str]
    install_hint: str
    capabilities: AgentCapabilities

    def _resolve_executable(self) -> str | None:
        for candidate in self.executable_candidates:
            resolved = shutil.which(candidate)
            if resolved:
                return resolved
        return None

    def info(self, context: RunContext | None = None) -> AgentAdapterInfo:
        executable = self._resolve_executable()
        launch = self.build_command(context) if context is not None and (executable or self.id in {"custom", "shell"}) else ([executable] + self.default_args if executable else [])
        return AgentAdapterInfo(
            id=self.id,
            display_name=self.display_name,
            executable=executable,
            installed=bool(executable) or self.id in {"custom", "shell"},
            launch_command=launch,
            capabilities=self.capabilities,
            install_hint=self.install_hint,
        )

    def build_command(self, context: RunContext) -> list[str]:
        executable = self._resolve_executable()
        if not executable:
            raise FileNotFoundError(f"Adapter '{self.id}' executable not found. {self.install_hint}")
        return [executable] + self.default_args

    def prepare_stdin(self, prompt: str, context: RunContext) -> str:
        return prompt.rstrip() + "\n"


class CustomAdapter(GenericInteractiveAdapter):
    def __init__(self) -> None:
        super().__init__(
            id="custom",
            display_name="Custom CLI Agent",
            executable_candidates=[],
            default_args=[],
            install_hint="Pass --custom-command, e.g. --custom-command 'my-agent --project .'",
            capabilities=AgentCapabilities(notes="Runs the exact command provided by --custom-command."),
        )

    def info(self, context: RunContext | None = None) -> AgentAdapterInfo:
        command = shlex.split(context.custom_command) if context and context.custom_command else []
        executable = shutil.which(command[0]) if command else None
        return AgentAdapterInfo(
            id=self.id,
            display_name=self.display_name,
            executable=executable,
            installed=bool(command and (executable or Path(command[0]).exists())),
            launch_command=command,
            capabilities=self.capabilities,
            install_hint=self.install_hint,
        )

    def build_command(self, context: RunContext) -> list[str]:
        if not context.custom_command:
            raise ValueError("--custom-command is required with --agent custom")
        return shlex.split(context.custom_command)


class ShellAdapter(GenericInteractiveAdapter):
    def __init__(self) -> None:
        shell = os.environ.get("SHELL") or "/bin/sh"
        super().__init__(
            id="shell",
            display_name="Shell Script Adapter",
            executable_candidates=[shell, "bash", "sh"],
            default_args=[],
            install_hint="A POSIX-compatible shell is required.",
            capabilities=AgentCapabilities(interactive=False, supports_prompt_stdin=False, edits_files=False, runs_commands=True, notes="Executes --shell-command, then Agentkodex gates."),
        )

    def build_command(self, context: RunContext) -> list[str]:
        shell = self._resolve_executable() or "/bin/sh"
        command = context.shell_command or "echo 'Agentkodex shell adapter: no --shell-command supplied; running gates only.'"
        return [shell, "-lc", command]

    def prepare_stdin(self, prompt: str, context: RunContext) -> str:
        return ""


REGISTRY: dict[str, Adapter] = {
    "codex": GenericInteractiveAdapter(
        id="codex",
        display_name="OpenAI Codex CLI",
        executable_candidates=["codex"],
        default_args=[],
        install_hint="Install Codex CLI, then make sure `codex` is on PATH.",
        capabilities=AgentCapabilities(notes="Interactive Codex CLI session controlled through PTY."),
    ),
    "claude-code": GenericInteractiveAdapter(
        id="claude-code",
        display_name="Claude Code",
        executable_candidates=["claude"],
        default_args=[],
        install_hint="Install Claude Code, then make sure `claude` is on PATH.",
        capabilities=AgentCapabilities(notes="Interactive Claude Code session controlled through PTY."),
    ),
    "aider": GenericInteractiveAdapter(
        id="aider",
        display_name="Aider",
        executable_candidates=["aider"],
        default_args=[],
        install_hint="Install Aider, then make sure `aider` is on PATH.",
        capabilities=AgentCapabilities(notes="Interactive Aider session controlled through PTY."),
    ),
    "gemini": GenericInteractiveAdapter(
        id="gemini",
        display_name="Gemini CLI",
        executable_candidates=["gemini"],
        default_args=[],
        install_hint="Install Gemini CLI, then make sure `gemini` is on PATH.",
        capabilities=AgentCapabilities(notes="Interactive Gemini CLI session controlled through PTY."),
    ),
    "opencode": GenericInteractiveAdapter(
        id="opencode",
        display_name="OpenCode",
        executable_candidates=["opencode"],
        default_args=[],
        install_hint="Install OpenCode, then make sure `opencode` is on PATH.",
        capabilities=AgentCapabilities(notes="Interactive OpenCode session controlled through PTY."),
    ),
    "cursor": GenericInteractiveAdapter(
        id="cursor",
        display_name="Cursor CLI Agent",
        executable_candidates=["cursor-agent", "cursor"],
        default_args=[],
        install_hint="Install Cursor CLI/agent, then make sure its executable is on PATH.",
        capabilities=AgentCapabilities(notes="Interactive Cursor agent session controlled through PTY."),
    ),
    "custom": CustomAdapter(),
    "shell": ShellAdapter(),
}


def get_adapter(agent_id: str) -> Adapter:
    try:
        return REGISTRY[agent_id]
    except KeyError as exc:
        raise KeyError(f"Unknown agent adapter '{agent_id}'. Available: {', '.join(sorted(REGISTRY))}") from exc


def list_adapters(context: RunContext | None = None) -> list[AgentAdapterInfo]:
    return [adapter.info(context) for adapter in REGISTRY.values()]
