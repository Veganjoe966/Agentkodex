from __future__ import annotations

import time
from pathlib import Path

from .models import DiscoveryResult, QualityGateResult
from .policy import PolicyEngine
from .util import run_command, truncate_middle, redact_secrets


def resolve_gates(discovery: DiscoveryResult, gates: list[str] | None) -> list[tuple[str, str]]:
    requested = gates or []
    if not requested or requested == ["auto"]:
        requested = [name for name in ["lint", "test", "build"] if name in discovery.commands]
    resolved: list[tuple[str, str]] = []
    for gate in requested:
        if not gate:
            continue
        if gate in discovery.commands:
            resolved.append((gate, discovery.commands[gate].command))
        elif any(ch.isspace() for ch in gate):
            # explicit command passed as gate
            resolved.append((gate.split()[0], gate))
    return resolved


def run_quality_gates(repo: Path, gates: list[tuple[str, str]], policy: PolicyEngine, mode: str, yes: bool, timeout: int = 900) -> list[QualityGateResult]:
    results: list[QualityGateResult] = []
    for name, command in gates:
        decision = policy.decide(command, mode=mode, yes=yes)  # type: ignore[arg-type]
        if not decision.allowed:
            results.append(QualityGateResult(
                name=name,
                command=command,
                exit_code=126,
                passed=False,
                duration_seconds=0,
                stdout="",
                stderr=f"Blocked by Agentkodex policy: {decision.reason}",
            ))
            continue
        start = time.monotonic()
        try:
            completed = run_command(command, cwd=repo, timeout=timeout)
            duration = time.monotonic() - start
            results.append(QualityGateResult(
                name=name,
                command=command,
                exit_code=completed.returncode,
                passed=completed.returncode == 0,
                duration_seconds=duration,
                stdout=truncate_middle(redact_secrets(completed.stdout), 120_000),
                stderr=truncate_middle(redact_secrets(completed.stderr), 120_000),
            ))
        except Exception as exc:  # noqa: BLE001
            duration = time.monotonic() - start
            results.append(QualityGateResult(
                name=name,
                command=command,
                exit_code=125,
                passed=False,
                duration_seconds=duration,
                stdout="",
                stderr=f"Agentkodex failed to run gate: {exc}",
            ))
    return results


def score_gates(results: list[QualityGateResult], changed_files: list[str], exit_code: int | None) -> float:
    score = 0.0
    if exit_code == 0:
        score += 20.0
    elif exit_code is None:
        score += 5.0
    if changed_files:
        score += 20.0
    if results:
        passed = sum(1 for r in results if r.passed)
        score += 60.0 * (passed / len(results))
    else:
        score += 20.0
    return round(score, 2)
