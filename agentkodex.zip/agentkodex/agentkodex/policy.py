from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .models import CommandRisk, Mode
from .util import read_json, write_json, ensure_dir

DEFAULT_POLICY: dict[str, Any] = {
    "version": 1,
    "safe_patterns": [
        r"^pwd$",
        r"^ls(\s|$)",
        r"^find\s+\.(\s|$)",
        r"^rg(\s|$)",
        r"^grep(\s|$)",
        r"^cat\s+[^|;&`]+$",
        r"^sed\s+-n\s+",
        r"^git\s+(status|diff|show|log|branch|rev-parse)(\s|$)",
        r"^(npm|pnpm|yarn|bun)\s+(run\s+)?(test|lint|build|typecheck|check)(\s|$)",
        r"^python\s+-m\s+(pytest|unittest|ruff|mypy)(\s|$)",
        r"^go\s+(test|build|vet)(\s|$)",
        r"^cargo\s+(test|build|clippy|fmt)(\s|$)",
        r"^dotnet\s+(test|build)(\s|$)",
        r"^mvn\s+(test|package)(\s|$)",
        r"^(make|just|task)\s+(test|lint|build|check)(\s|$)",
        r"^echo(\s|$)",
    ],
    "approval_required_patterns": [
        r"^(npm|pnpm|yarn|bun)\s+(install|add|remove|update)(\s|$)",
        r"^python\s+-m\s+pip\s+install(\s|$)",
        r"^pip\s+install(\s|$)",
        r"^uv\s+(sync|add|remove)(\s|$)",
        r"^poetry\s+(install|add|remove|update)(\s|$)",
        r"^docker\s+compose\s+up(\s|$)",
        r"^docker\s+(build|run|pull)(\s|$)",
        r"^git\s+(commit|push|checkout\s+-b|switch\s+-c|merge|rebase)(\s|$)",
        r"^gh\s+pr\s+create(\s|$)",
        r"^(vercel|netlify|fly|railway)\s+(deploy|up)(\s|$)",
        r"^make\s+(install|setup|deploy|release)(\s|$)",
    ],
    "blocked_patterns": [
        r"rm\s+-rf\s+/$",
        r"rm\s+-rf\s+~",
        r"rm\s+-rf\s+\*",
        r"rm\s+-rf\s+\.git",
        r"sudo(\s|$)",
        r"chmod\s+-R\s+777",
        r"chown\s+-R",
        r"curl\s+[^|]+\|\s*(sh|bash)",
        r"wget\s+[^|]+\|\s*(sh|bash)",
        r"ssh\s+",
        r"scp\s+",
        r"rsync\s+",
        r"aws\s+.*(delete|terminate|destroy)",
        r"kubectl\s+delete",
        r"terraform\s+(destroy|apply)",
        r"drop\s+database",
        r"prisma\s+migrate\s+reset.*(--force|-f)",
        r"cat\s+~/(\.ssh|\.aws|\.config)",
        r"cat\s+\.env(\s|$)",
    ],
}


@dataclass(slots=True)
class PolicyDecision:
    risk: CommandRisk
    reason: str
    allowed: bool


class PolicyEngine:
    def __init__(self, policy: dict[str, Any] | None = None) -> None:
        self.policy = policy or DEFAULT_POLICY
        self.safe = [re.compile(p, re.IGNORECASE) for p in self.policy.get("safe_patterns", [])]
        self.approval = [re.compile(p, re.IGNORECASE) for p in self.policy.get("approval_required_patterns", [])]
        self.blocked = [re.compile(p, re.IGNORECASE) for p in self.policy.get("blocked_patterns", [])]

    def classify(self, command: str) -> CommandRisk:
        stripped = " ".join(command.strip().split())
        if not stripped:
            return "blocked"
        for pattern in self.blocked:
            if pattern.search(stripped):
                return "blocked"
        for pattern in self.safe:
            if pattern.search(stripped):
                return "safe"
        for pattern in self.approval:
            if pattern.search(stripped):
                return "approval_required"
        # Unknown commands can mutate or leak secrets. Require approval by default.
        return "approval_required"

    def decide(self, command: str, mode: Mode, yes: bool = False) -> PolicyDecision:
        risk = self.classify(command)
        if risk == "blocked":
            return PolicyDecision(risk=risk, reason="Command matches blocked policy", allowed=False)
        if mode == "observe" and risk != "safe":
            return PolicyDecision(risk=risk, reason="Observe mode only allows safe commands", allowed=False)
        if risk == "approval_required" and mode == "supervised" and not yes:
            return PolicyDecision(risk=risk, reason="Supervised mode requires approval for this command", allowed=False)
        return PolicyDecision(risk=risk, reason="Allowed by mode and policy", allowed=True)


def policy_path(repo: Path) -> Path:
    return repo / ".agentkodex" / "policy.json"


def load_policy(repo: Path) -> dict[str, Any]:
    return read_json(policy_path(repo), default=DEFAULT_POLICY) or DEFAULT_POLICY


def write_default_policy(repo: Path, force: bool = False) -> None:
    path = policy_path(repo)
    ensure_dir(path.parent)
    if force or not path.exists():
        write_json(path, DEFAULT_POLICY)
