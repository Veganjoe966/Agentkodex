from __future__ import annotations

from pathlib import Path
from typing import Any

from .util import read_json, write_json, ensure_dir

DEFAULT_CONFIG: dict[str, Any] = {
    "version": 1,
    "default_agent": "codex",
    "default_mode": "supervised",
    "default_gates": ["lint", "test", "build"],
    "redact_secrets": True,
    "terminal": {
        "idle_timeout_seconds": 20,
        "hard_timeout_seconds": 900,
        "max_output_chars": 500000,
    },
    "adapters": {
        "codex": {"command": "codex"},
        "claude-code": {"command": "claude"},
        "aider": {"command": "aider"},
        "gemini": {"command": "gemini"},
        "opencode": {"command": "opencode"},
        "cursor": {"command": "cursor-agent"},
    },
}


def agentkodex_dir(repo: Path) -> Path:
    return repo / ".agentkodex"


def config_path(repo: Path) -> Path:
    return agentkodex_dir(repo) / "config.json"


def load_config(repo: Path) -> dict[str, Any]:
    config = DEFAULT_CONFIG.copy()
    loaded = read_json(config_path(repo), default={}) or {}
    config.update(loaded)
    # nested merge for terminal/adapters
    for key in ["terminal", "adapters"]:
        merged = DEFAULT_CONFIG.get(key, {}).copy()
        merged.update(loaded.get(key, {}) if isinstance(loaded.get(key), dict) else {})
        config[key] = merged
    return config


def write_default_config(repo: Path, force: bool = False) -> None:
    path = config_path(repo)
    ensure_dir(path.parent)
    if force or not path.exists():
        write_json(path, DEFAULT_CONFIG)
