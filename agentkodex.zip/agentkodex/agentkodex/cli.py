from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from . import __version__
from .adapters import list_adapters, REGISTRY
from .discovery import discover_project
from .kodex import KodexStore
from .orchestrator import discover_and_write, init_repo, make_context, run_agent, run_tournament
from .planner import generate_plan, suggest_agent
from .policy import PolicyEngine, load_policy
from .util import bold, green, red, yellow, emit_yaml, human_duration, shlex_join, read_text


def _repo(path: str | None) -> Path:
    return Path(path or os.getcwd()).resolve()


def cmd_init(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    init_repo(repo, force=args.force)
    print(green(f"Initialized Agentkodex in {repo / '.agentkodex'}"))
    return 0


def cmd_discover(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    discovery = discover_and_write(repo)
    if args.json:
        print(json.dumps(discovery.to_dict(), indent=2, sort_keys=True))
    elif args.yaml:
        print(emit_yaml(discovery.to_dict()))
    else:
        print(bold("Agentkodex discovery"))
        print(f"Repo: {discovery.repo}")
        print(f"Languages: {', '.join(discovery.languages) if discovery.languages else 'unknown'}")
        print(f"Frameworks: {', '.join(discovery.frameworks) if discovery.frameworks else 'unknown'}")
        print(f"Package managers: {', '.join(discovery.package_managers) if discovery.package_managers else 'unknown'}")
        print("Commands:")
        for name, spec in sorted(discovery.commands.items()):
            req = " required" if spec.required else ""
            print(f"  - {name}: {spec.command} [{spec.confidence}, {spec.source}{req}]")
        if discovery.warnings:
            print(yellow("Warnings:"))
            for warning in discovery.warnings:
                print(f"  - {warning}")
        print(f"Wrote {repo / '.agentkodex' / 'project.kodex.md'}")
    return 0


def cmd_agents(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    context = make_context(repo, "adapter inspection", args.agent or "shell", args.mode, custom_command=args.custom_command, shell_command=args.shell_command)
    infos = list_adapters(context)
    if args.json:
        print(json.dumps([_adapter_info_to_dict(info) for info in infos], indent=2, sort_keys=True))
        return 0
    print(bold("Agentkodex adapters"))
    for info in infos:
        installed = green("installed") if info.installed else red("missing")
        command = shlex_join(info.launch_command) if info.launch_command else "-"
        print(f"- {info.id:12} {installed:20} command: {command}")
        if not info.installed:
            print(f"  hint: {info.install_hint}")
    return 0


def _adapter_info_to_dict(info: Any) -> dict[str, Any]:
    return {
        "id": info.id,
        "display_name": info.display_name,
        "executable": info.executable,
        "installed": info.installed,
        "launch_command": info.launch_command,
        "install_hint": info.install_hint,
        "capabilities": {
            "interactive": info.capabilities.interactive,
            "supports_prompt_stdin": info.capabilities.supports_prompt_stdin,
            "edits_files": info.capabilities.edits_files,
            "runs_commands": info.capabilities.runs_commands,
            "notes": info.capabilities.notes,
        },
    }


def _parse_gates(raw: str | None) -> list[str]:
    if not raw:
        return ["auto"]
    return [part.strip() for part in raw.split(",") if part.strip()]


def cmd_run(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    if args.agent not in REGISTRY:
        print(red(f"Unknown agent '{args.agent}'. Available: {', '.join(sorted(REGISTRY))}"), file=sys.stderr)
        return 2
    context = make_context(
        repo=repo,
        task=args.task,
        agent_id=args.agent,
        mode=args.mode,
        yes=args.yes,
        gates=_parse_gates(args.gates),
        custom_command=args.custom_command,
        shell_command=args.shell_command,
        project_cli=args.project_cli,
        timeout=args.timeout,
        idle_timeout=args.idle_timeout,
    )
    print(bold(f"Agentkodex run {context.run_id}"))
    print(f"Repo: {repo}")
    print(f"Agent: {args.agent}")
    print(f"Mode: {args.mode}")
    print(f"Run dir: {context.run_dir}")
    result = run_agent(context, stream=args.stream)
    _print_run_result(result)
    return 0 if result.status == "passed" else 1


def _print_run_result(result: Any) -> None:
    status_text = green(result.status) if result.status == "passed" else red(result.status)
    print(bold("Result"))
    print(f"Status: {status_text}")
    print(f"Score: {result.score}")
    print(f"Run dir: {result.run_dir}")
    print(f"Message: {result.message}")
    if result.changed_files:
        print("Changed files:")
        for file in result.changed_files:
            print(f"  - {file}")
    if result.gates:
        print("Quality gates:")
        for gate in result.gates:
            icon = green("PASS") if gate.passed else red("FAIL")
            print(f"  - {icon} {gate.name}: `{gate.command}` exit={gate.exit_code} duration={human_duration(gate.duration_seconds)}")


def cmd_status(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    runs = KodexStore(repo).list_runs()
    if args.json:
        print(json.dumps(runs, indent=2, sort_keys=True))
        return 0
    if not runs:
        print("No Agentkodex runs found.")
        return 0
    print(bold("Agentkodex runs"))
    for run in runs[: args.limit]:
        print(f"- {run.get('run_id')} status={run.get('status')} agent={run.get('agent_id')} score={run.get('score', '-')}")
        print(f"  {run.get('task', '')[:120]}")
    return 0


def cmd_replay(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    store = KodexStore(repo)
    run_dir = Path(args.run_dir) if args.run_dir else (store.runs_dir / args.run_id if args.run_id else store.latest_run_dir())
    if not run_dir or not run_dir.exists():
        print(red("Run not found."), file=sys.stderr)
        return 1
    file_name = "summary.md" if args.summary else "transcript.txt"
    content = read_text(run_dir / file_name, default="")
    if not content:
        print(yellow(f"No {file_name} found in {run_dir}"))
        return 1
    print(content)
    return 0


def cmd_kodex(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    store = KodexStore(repo)
    if args.kodex_cmd == "show":
        print(store.read_project_markdown() or "No project Kodex found. Run `agentkodex discover`.")
        return 0
    if args.kodex_cmd == "path":
        print(store.root)
        return 0
    print(red("Unknown kodex command"), file=sys.stderr)
    return 2


def cmd_policy(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    engine = PolicyEngine(load_policy(repo))
    if args.policy_cmd == "check":
        decision = engine.decide(args.command, args.mode, yes=args.yes)
        payload = {"command": args.command, "risk": decision.risk, "allowed": decision.allowed, "reason": decision.reason}
        if args.json:
            print(json.dumps(payload, indent=2, sort_keys=True))
        else:
            print(f"risk={decision.risk} allowed={decision.allowed} reason={decision.reason}")
        return 0 if decision.allowed else 1
    print(red("Unknown policy command"), file=sys.stderr)
    return 2


def cmd_tournament(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    agents = [a.strip() for a in args.agents.split(",") if a.strip()]
    unknown = [a for a in agents if a not in REGISTRY]
    if unknown:
        print(red(f"Unknown agents: {', '.join(unknown)}"), file=sys.stderr)
        return 2
    payload = run_tournament(
        repo=repo,
        task=args.task,
        agents=agents,
        mode=args.mode,
        yes=args.yes,
        gates=_parse_gates(args.gates),
        timeout=args.timeout,
        idle_timeout=args.idle_timeout,
        stream=args.stream,
    )
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(bold(f"Tournament {payload['run_id']}"))
        winner = payload.get("winner")
        if winner:
            print(green(f"Winner: {winner['agent_id']} score={winner['score']} status={winner['status']}"))
        for result in payload.get("results", []):
            print(f"- {result['agent_id']}: status={result['status']} score={result['score']} run_dir={result['run_dir']}")
    return 0



def cmd_plan(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    discovery = discover_project(repo)
    plan = generate_plan(args.task, discovery, _parse_gates(args.gates))
    if args.write:
        store = KodexStore(repo)
        store.init(force=False)
        target = store.root / "last_plan.md"
        target.write_text(plan, encoding="utf-8")
        print(f"Wrote {target}")
    print(plan)
    return 0


def cmd_suggest(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    discovery = discover_project(repo)
    installed = {info.id: info.installed for info in list_adapters()}
    suggestion = suggest_agent(args.task, discovery, installed)
    if args.json:
        print(json.dumps(suggestion, indent=2, sort_keys=True))
    else:
        print(bold("Agentkodex suggestion"))
        print(f"Recommended agent: {green(str(suggestion['recommended_agent']))}")
        for row in suggestion["ranked"]:
            print(f"- {row['agent']}: score={row['score']}")
            for reason in row.get("reasons", [])[:3]:
                print(f"  - {reason}")
    return 0

def cmd_doctor(args: argparse.Namespace) -> int:
    repo = _repo(args.repo)
    print(bold("Agentkodex doctor"))
    print(f"Version: {__version__}")
    print(f"Repo: {repo}")
    print(f"Python: {sys.version.split()[0]}")
    store = KodexStore(repo)
    print(f"Kodex directory: {store.root} {'exists' if store.root.exists() else 'missing'}")
    print("Adapters:")
    for info in list_adapters():
        status = "ok" if info.installed else "missing"
        print(f"  - {info.id}: {status} ({info.executable or info.install_hint})")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="agentkodex", description="CLI-native agent harness for autonomous software delivery")
    parser.add_argument("--version", action="version", version=f"agentkodex {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="Initialize .agentkodex memory in a repo")
    p.add_argument("--repo", default=None)
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("discover", help="Discover project commands and write Kodex memory")
    p.add_argument("--repo", default=None)
    p.add_argument("--json", action="store_true")
    p.add_argument("--yaml", action="store_true")
    p.set_defaults(func=cmd_discover)

    p = sub.add_parser("agents", help="List available agent adapters")
    p.add_argument("--repo", default=None)
    p.add_argument("--json", action="store_true")
    p.add_argument("--agent", default="shell")
    p.add_argument("--mode", choices=["observe", "supervised", "sandbox-auto", "trusted-auto"], default="supervised")
    p.add_argument("--custom-command", default=None)
    p.add_argument("--shell-command", default=None)
    p.set_defaults(func=cmd_agents)

    p = sub.add_parser("run", help="Run a task through a selected CLI agent adapter")
    p.add_argument("task")
    p.add_argument("--repo", default=None)
    p.add_argument("--agent", choices=sorted(REGISTRY), default="codex")
    p.add_argument("--mode", choices=["observe", "supervised", "sandbox-auto", "trusted-auto"], default="supervised")
    p.add_argument("--gates", default="auto", help="Comma-separated gate names or explicit commands. Default: auto")
    p.add_argument("--custom-command", default=None)
    p.add_argument("--shell-command", default=None)
    p.add_argument("--project-cli", default=None)
    p.add_argument("--yes", action="store_true", help="Approve policy approval_required commands in supervised mode")
    p.add_argument("--timeout", type=int, default=900)
    p.add_argument("--idle-timeout", type=int, default=20)
    p.add_argument("--stream", action="store_true", help="Stream PTY output to stdout while recording")
    p.set_defaults(func=cmd_run)

    p = sub.add_parser("status", help="List previous Agentkodex runs")
    p.add_argument("--repo", default=None)
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("replay", help="Replay a previous run transcript")
    p.add_argument("--repo", default=None)
    p.add_argument("--run-id", default=None)
    p.add_argument("--run-dir", default=None)
    p.add_argument("--summary", action="store_true")
    p.set_defaults(func=cmd_replay)

    p = sub.add_parser("tournament", help="Compare multiple agents on the same task in isolated copies")
    p.add_argument("--repo", default=None)
    p.add_argument("--task", required=True)
    p.add_argument("--agents", required=True, help="Comma-separated adapter IDs")
    p.add_argument("--mode", choices=["observe", "supervised", "sandbox-auto", "trusted-auto"], default="supervised")
    p.add_argument("--gates", default="auto")
    p.add_argument("--yes", action="store_true")
    p.add_argument("--timeout", type=int, default=900)
    p.add_argument("--idle-timeout", type=int, default=20)
    p.add_argument("--stream", action="store_true")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_tournament)

    p = sub.add_parser("kodex", help="Inspect project Kodex memory")
    p.add_argument("--repo", default=None)
    kodex_sub = p.add_subparsers(dest="kodex_cmd", required=True)
    p_show = kodex_sub.add_parser("show", help="Show project.kodex.md")
    p_show.set_defaults(func=cmd_kodex)
    p_path = kodex_sub.add_parser("path", help="Print .agentkodex path")
    p_path.set_defaults(func=cmd_kodex)

    p = sub.add_parser("policy", help="Inspect command policy")
    p.add_argument("--repo", default=None)
    policy_sub = p.add_subparsers(dest="policy_cmd", required=True)
    p_check = policy_sub.add_parser("check", help="Check command risk")
    p_check.add_argument("command")
    p_check.add_argument("--mode", choices=["observe", "supervised", "sandbox-auto", "trusted-auto"], default="supervised")
    p_check.add_argument("--yes", action="store_true")
    p_check.add_argument("--json", action="store_true")
    p_check.set_defaults(func=cmd_policy)


    p = sub.add_parser("plan", help="Generate an Agentkodex execution plan without running an agent")
    p.add_argument("task")
    p.add_argument("--repo", default=None)
    p.add_argument("--gates", default="auto")
    p.add_argument("--write", action="store_true", help="Write plan to .agentkodex/last_plan.md")
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("suggest", help="Suggest the best adapter for a task and repo")
    p.add_argument("task")
    p.add_argument("--repo", default=None)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_suggest)

    p = sub.add_parser("doctor", help="Check local environment")
    p.add_argument("--repo", default=None)
    p.set_defaults(func=cmd_doctor)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
