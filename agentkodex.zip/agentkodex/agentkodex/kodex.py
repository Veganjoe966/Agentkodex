from __future__ import annotations

from pathlib import Path
from typing import Any

from .config import agentkodex_dir, write_default_config
from .models import DiscoveryResult, QualityGateResult, RunContext, RunResult
from .policy import write_default_policy
from .prompts import KERNEL_PROMPT, BUILDER_PROMPT, DEBUGGER_PROMPT, QA_PROMPT, SECURITY_PROMPT
from .util import ensure_dir, emit_yaml, now_utc_iso, read_json, read_text, write_json, write_text, redact_secrets

PROMPT_FILES = {
    "kernel.md": KERNEL_PROMPT,
    "builder.md": BUILDER_PROMPT,
    "debugger.md": DEBUGGER_PROMPT,
    "qa.md": QA_PROMPT,
    "security.md": SECURITY_PROMPT,
}


class KodexStore:
    def __init__(self, repo: Path) -> None:
        self.repo = repo.resolve()
        self.root = agentkodex_dir(self.repo)
        self.runs_dir = self.root / "runs"
        self.prompts_dir = self.root / "prompts"

    def init(self, force: bool = False) -> None:
        ensure_dir(self.root)
        ensure_dir(self.runs_dir)
        ensure_dir(self.prompts_dir)
        ensure_dir(self.root / "agents")
        write_default_config(self.repo, force=force)
        write_default_policy(self.repo, force=force)
        for name, content in PROMPT_FILES.items():
            target = self.prompts_dir / name
            if force or not target.exists():
                write_text(target, content)
        errors = self.root / "errors.kodex.json"
        if force or not errors.exists():
            write_json(errors, {"version": 1, "known_errors": []})
        project = self.root / "project.kodex.md"
        if force or not project.exists():
            write_text(project, "# Project Kodex\n\nRun `agentkodex discover` to populate project command memory.\n")

    def write_discovery(self, discovery: DiscoveryResult) -> None:
        self.init(force=False)
        data = discovery.to_dict()
        write_json(self.root / "commands.kodex.json", data)
        write_text(self.root / "commands.kodex.yaml", emit_yaml(data) + "\n")
        write_text(self.root / "project.kodex.md", self._render_project_markdown(discovery))

    def read_discovery_data(self) -> dict[str, Any]:
        return read_json(self.root / "commands.kodex.json", default={}) or {}

    def read_project_markdown(self) -> str:
        return read_text(self.root / "project.kodex.md", default="")

    def create_run_dir(self, run_id: str) -> Path:
        return ensure_dir(self.runs_dir / run_id)

    def write_run_start(self, context: RunContext, prompt: str) -> None:
        ensure_dir(context.run_dir)
        write_text(context.run_dir / "task.md", context.task + "\n")
        write_text(context.run_dir / "prompt.md", prompt)
        write_json(context.run_dir / "run.json", {
            "run_id": context.run_id,
            "status": "running",
            "agent_id": context.agent_id,
            "mode": context.mode,
            "repo": str(context.repo),
            "started_at": now_utc_iso(),
            "task": context.task,
            "gates": context.gates,
            "custom_command": context.custom_command,
            "shell_command": context.shell_command,
        })

    def append_transcript(self, run_dir: Path, text: str) -> None:
        path = run_dir / "transcript.txt"
        with path.open("a", encoding="utf-8") as f:
            f.write(redact_secrets(text))

    def append_command_log(self, run_dir: Path, command: str, exit_code: int | None = None, risk: str | None = None) -> None:
        path = run_dir / "commands.log"
        line = f"[{now_utc_iso()}]"
        if risk:
            line += f" risk={risk}"
        line += f" command={command}"
        if exit_code is not None:
            line += f" exit_code={exit_code}"
        line += "\n"
        with path.open("a", encoding="utf-8") as f:
            f.write(line)

    def write_summary(self, result: RunResult, diff: str, security_report: str) -> None:
        run_dir = Path(result.run_dir)
        write_text(run_dir / "diff.patch", diff)
        write_text(run_dir / "security_report.md", security_report)
        write_json(run_dir / "qa_report.json", {
            "status": result.status,
            "score": result.score,
            "changed_files": result.changed_files,
            "gates": [gate.to_dict() for gate in result.gates],
            "message": result.message,
        })
        write_json(run_dir / "run.json", {
            **(read_json(run_dir / "run.json", default={}) or {}),
            "status": result.status,
            "finished_at": now_utc_iso(),
            "score": result.score,
            "changed_files": result.changed_files,
            "message": result.message,
        })
        lines = [
            f"# Agentkodex Run {result.run_id}",
            "",
            f"Status: **{result.status}**",
            f"Agent: `{result.agent_id}`",
            f"Repo: `{result.repo}`",
            f"Score: `{result.score:.2f}`",
            "",
            "## Changed files",
            "",
        ]
        if result.changed_files:
            lines.extend(f"- `{f}`" for f in result.changed_files)
        else:
            lines.append("No changed files detected.")
        lines.extend(["", "## Quality gates", ""])
        if result.gates:
            for gate in result.gates:
                icon = "PASS" if gate.passed else "FAIL"
                lines.append(f"- {icon} `{gate.command}` exit={gate.exit_code} duration={gate.duration_seconds:.1f}s")
        else:
            lines.append("No quality gates were run.")
        lines.extend(["", "## Message", "", result.message, ""])
        write_text(run_dir / "summary.md", "\n".join(lines))

    def list_runs(self) -> list[dict[str, Any]]:
        if not self.runs_dir.exists():
            return []
        runs = []
        for path in sorted(self.runs_dir.iterdir(), reverse=True):
            if path.is_dir():
                data = read_json(path / "run.json", default={}) or {}
                if data:
                    data["run_dir"] = str(path)
                    runs.append(data)
        return runs

    def latest_run_dir(self) -> Path | None:
        runs = self.list_runs()
        if not runs:
            return None
        return Path(runs[0]["run_dir"])

    def _render_project_markdown(self, discovery: DiscoveryResult) -> str:
        lines = [
            "# Project Kodex",
            "",
            f"Generated: {now_utc_iso()}",
            f"Repository: `{discovery.repo}`",
            "",
            "## Stack",
            "",
            f"Languages: {', '.join(discovery.languages) if discovery.languages else 'unknown'}",
            f"Frameworks: {', '.join(discovery.frameworks) if discovery.frameworks else 'unknown'}",
            f"Package managers: {', '.join(discovery.package_managers) if discovery.package_managers else 'unknown'}",
            "",
            "## Commands",
            "",
        ]
        if discovery.commands:
            for name, spec in sorted(discovery.commands.items()):
                req = " required" if spec.required else ""
                lines.append(f"- `{name}`: `{spec.command}` ({spec.confidence}, {spec.source}{req})")
        else:
            lines.append("No commands discovered.")
        lines.extend(["", "## Files", ""])
        if discovery.env_files:
            lines.append("Environment examples: " + ", ".join(f"`{x}`" for x in discovery.env_files))
        if discovery.service_files:
            lines.append("Service files: " + ", ".join(f"`{x}`" for x in discovery.service_files))
        if discovery.ci_files:
            lines.append("CI files: " + ", ".join(f"`{x}`" for x in discovery.ci_files))
        if discovery.warnings:
            lines.extend(["", "## Warnings", ""])
            lines.extend(f"- {warning}" for warning in discovery.warnings)
        lines.append("")
        return "\n".join(lines)
