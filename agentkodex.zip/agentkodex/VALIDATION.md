# Agentkodex Validation

Validated on: 2026-06-03T03:19:22Z

## Unit and smoke tests
```text
test_cli_init_discover_shell_run (test_cli_smoke.CliSmokeTests.test_cli_init_discover_shell_run) ... ok
test_node_project_detection (test_discovery.DiscoveryTests.test_node_project_detection) ... ok
test_python_project_detection (test_discovery.DiscoveryTests.test_python_project_detection) ... ok
test_approval_required (test_policy.PolicyTests.test_approval_required) ... ok
test_blocked (test_policy.PolicyTests.test_blocked) ... ok
test_safe_command (test_policy.PolicyTests.test_safe_command) ... ok

----------------------------------------------------------------------
Ran 6 tests in 7.206s

OK
```

## Doctor
```text
Agentkodex doctor
Version: 0.1.0
Repo: /tmp/tmp.2oxphnXq7S
Python: 3.13.5
Kodex directory: /tmp/tmp.2oxphnXq7S/.agentkodex missing
Adapters:
  - codex: missing (Install Codex CLI, then make sure `codex` is on PATH.)
  - claude-code: missing (Install Claude Code, then make sure `claude` is on PATH.)
  - aider: missing (Install Aider, then make sure `aider` is on PATH.)
  - gemini: missing (Install Gemini CLI, then make sure `gemini` is on PATH.)
  - opencode: missing (Install OpenCode, then make sure `opencode` is on PATH.)
  - cursor: missing (Install Cursor CLI/agent, then make sure its executable is on PATH.)
  - custom: missing (Pass --custom-command, e.g. --custom-command 'my-agent --project .')
  - shell: ok (/bin/sh)
```

## Init and discover
```text
Initialized Agentkodex in /tmp/tmp.2oxphnXq7S/.agentkodex
Agentkodex discovery
Repo: /tmp/tmp.2oxphnXq7S
Languages: javascript/typescript
Frameworks: nextjs, react
Package managers: npm
Commands:
  - add_dependency: npm install [medium, package manager detection]
  - build: npm run build [high, package.json scripts.build required]
  - install: npm install [high, package manager detection]
  - lint: npm run lint [high, package.json scripts.lint required]
  - test: npm run test [high, package.json scripts.test required]
Wrote /tmp/tmp.2oxphnXq7S/.agentkodex/project.kodex.md
```

## Shell adapter run with gates
```text
Agentkodex run 20260603-031939-shell-30f99c
Repo: /tmp/tmp.2oxphnXq7S
Agent: shell
Mode: supervised
Run dir: /tmp/tmp.2oxphnXq7S/.agentkodex/runs/20260603-031939-shell-30f99c
Result
Status: passed
Score: 80.0
Run dir: /tmp/tmp.2oxphnXq7S/.agentkodex/runs/20260603-031939-shell-30f99c
Message: Adapter process exited with code 0. All quality gates passed.
Quality gates:
  - PASS test: `npm run test` exit=0 duration=0.3s
  - PASS build: `npm run build` exit=0 duration=0.3s
```

## Custom adapter run with gates
```text
Agentkodex run 20260603-031942-custom-3f5824
Repo: /tmp/tmp.2oxphnXq7S
Agent: custom
Mode: supervised
Run dir: /tmp/tmp.2oxphnXq7S/.agentkodex/runs/20260603-031942-custom-3f5824
Result
Status: passed
Score: 80.0
Run dir: /tmp/tmp.2oxphnXq7S/.agentkodex/runs/20260603-031942-custom-3f5824
Message: Adapter process exited with code 0. All quality gates passed.
Quality gates:
  - PASS test: `npm run test` exit=0 duration=0.4s
  - PASS build: `npm run build` exit=0 duration=0.3s
```
