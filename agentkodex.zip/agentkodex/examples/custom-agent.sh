#!/usr/bin/env bash
set -euo pipefail
# Tiny fake agent useful for validating Agentkodex without installing a paid coding agent.
echo "Custom agent received Agentkodex prompt:"
head -n 20 || true
echo "AGENTKODEX_DONE"
