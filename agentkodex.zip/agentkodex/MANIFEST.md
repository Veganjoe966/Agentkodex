# Agentkodex Artifact Manifest

This package contains a working local-first implementation of the enhanced Agentkodex idea.

Core files:

- `agentkodex/cli.py`: command-line interface
- `agentkodex/orchestrator.py`: run loop and tournament orchestration
- `agentkodex/pty_runner.py`: persistent pseudo-terminal runner
- `agentkodex/adapters.py`: Codex, Claude Code, Aider, Gemini, OpenCode, Cursor, Custom, Shell adapters
- `agentkodex/discovery.py`: project command discovery
- `agentkodex/kodex.py`: project memory and run artifacts
- `agentkodex/policy.py`: command risk policy
- `agentkodex/gates.py`: quality gate execution and scoring
- `agentkodex/security.py`: lightweight static security review
- `agentkodex/prompts.py`: production prompt stack
- `agentkodex/planner.py`: execution planning and adapter recommendation router
- `tests/`: working unit and smoke tests

Validation performed before delivery:

```bash
python -m unittest discover -s tests -v
python -m agentkodex doctor --repo /mnt/data/agentkodex
python -m agentkodex init --repo /tmp/sample
python -m agentkodex discover --repo /tmp/sample --json
python -m agentkodex run --agent shell --shell-command "echo hello" --gates test,build "Smoke test"
```
