from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class CliSmokeTests(unittest.TestCase):
    def test_cli_init_discover_shell_run(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            (repo / "package.json").write_text(json.dumps({"scripts": {"test": "echo ok", "build": "echo build"}}), encoding="utf-8")
            init = subprocess.run([sys.executable, "-m", "agentkodex", "init", "--repo", str(repo)], capture_output=True, text=True)
            self.assertEqual(init.returncode, 0, init.stderr)
            discover = subprocess.run([sys.executable, "-m", "agentkodex", "discover", "--repo", str(repo), "--json"], capture_output=True, text=True)
            self.assertEqual(discover.returncode, 0, discover.stderr)
            self.assertIn("commands", discover.stdout)
            run = subprocess.run([
                sys.executable, "-m", "agentkodex", "run", "Smoke test", "--repo", str(repo), "--agent", "shell", "--shell-command", "echo hello", "--gates", "test,build", "--idle-timeout", "1", "--timeout", "20"
            ], capture_output=True, text=True)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            self.assertTrue((repo / ".agentkodex" / "runs").exists())


if __name__ == "__main__":
    unittest.main()
