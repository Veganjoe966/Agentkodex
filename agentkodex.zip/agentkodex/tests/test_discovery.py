from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from agentkodex.discovery import discover_project


class DiscoveryTests(unittest.TestCase):
    def test_node_project_detection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            (repo / "pnpm-lock.yaml").write_text("lockfileVersion: 9\n", encoding="utf-8")
            (repo / "package.json").write_text(json.dumps({
                "scripts": {"dev": "next dev", "build": "next build", "test": "vitest", "lint": "eslint ."},
                "dependencies": {"next": "latest", "react": "latest"},
                "devDependencies": {"typescript": "latest"},
            }), encoding="utf-8")
            result = discover_project(repo)
            self.assertIn("javascript/typescript", result.languages)
            self.assertIn("nextjs", result.frameworks)
            self.assertIn("pnpm", result.package_managers)
            self.assertEqual(result.commands["build"].command, "pnpm build")
            self.assertTrue(result.commands["test"].required)

    def test_python_project_detection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            (repo / "pyproject.toml").write_text('[project]\ndependencies=["pytest", "ruff", "fastapi"]\n', encoding="utf-8")
            result = discover_project(repo)
            self.assertIn("python", result.languages)
            self.assertIn("fastapi", result.frameworks)
            self.assertEqual(result.commands["test"].command, "python -m pytest")
            self.assertEqual(result.commands["lint"].command, "python -m ruff check .")


if __name__ == "__main__":
    unittest.main()
