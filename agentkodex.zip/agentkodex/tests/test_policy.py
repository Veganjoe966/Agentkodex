from __future__ import annotations

import unittest

from agentkodex.policy import PolicyEngine


class PolicyTests(unittest.TestCase):
    def test_safe_command(self) -> None:
        engine = PolicyEngine()
        decision = engine.decide("pnpm test", "supervised")
        self.assertTrue(decision.allowed)
        self.assertEqual(decision.risk, "safe")

    def test_approval_required(self) -> None:
        engine = PolicyEngine()
        decision = engine.decide("pnpm add react", "supervised", yes=False)
        self.assertFalse(decision.allowed)
        self.assertEqual(decision.risk, "approval_required")
        decision_yes = engine.decide("pnpm add react", "supervised", yes=True)
        self.assertTrue(decision_yes.allowed)

    def test_blocked(self) -> None:
        engine = PolicyEngine()
        decision = engine.decide("rm -rf /", "trusted-auto", yes=True)
        self.assertFalse(decision.allowed)
        self.assertEqual(decision.risk, "blocked")


if __name__ == "__main__":
    unittest.main()
