# Agentkodex

**Agentkodex** is a local-first, CLI-native harness for autonomous software delivery. It lets a developer choose a coding agent CLI such as Codex, Claude Code, Aider, Gemini CLI, or a custom command, then runs that agent inside a persistent terminal session against a real project. Agentkodex discovers the project's actual command ecosystem, injects a structured mission prompt, records the terminal session, runs quality gates, saves replayable logs, and updates a project-specific `.agentkodex` memory layer.

This repository is not a throwaway scaffold. It contains a working Python CLI package with no required third-party runtime dependencies.

## What works

- `agentkodex init` creates a durable project memory directory.
- `agentkodex discover` scans a project for languages, frameworks, package managers, scripts, service files, environment examples, and quality gates.
- `agentkodex agents` lists supported CLI agent adapters and whether their executables are installed.
- `agentkodex suggest` recommends an adapter for the current task and repo.
- `agentkodex plan` produces a deterministic execution plan before a run.
- `agentkodex run` starts the selected agent in a persistent pseudo-terminal, sends a full Agentkodex mission prompt, records output, captures diffs, runs gates, writes QA/security summaries, and stores a replayable run bundle.
- `agentkodex replay` prints a previous transcript or summary.
- `agentkodex status` lists previous runs.
- `agentkodex tournament` runs the same task through multiple agent adapters in isolated copies of the repo and compares the outcomes.
- `agentkodex kodex show` prints discovered project memory.
- `agentkodex doctor` checks your environment.

## Install locally

From this folder:

```bash
python -m pip install -e .
agentkodex --help
```

Or run without installing:

```bash
python -m agentkodex --help
```

## Fast start

Inside any software project:

```bash
agentkodex init
agentkodex discover
agentkodex agents
agentkodex suggest "Add password reset and verify with tests"
agentkodex plan "Add password reset and verify with tests"
agentkodex run --agent claude-code --mode supervised "Add password reset and verify with tests"
```

For a custom CLI agent:

```bash
agentkodex run \
  --agent custom \
  --custom-command "my-agent-cli --project ." \
  --mode supervised \
  "Build the dashboard settings page and run the test suite"
```

For a non-agent smoke test of the harness:

```bash
agentkodex run --agent shell --shell-command "echo Agentkodex shell adapter works" "Smoke test"
```

## Tournament mode

```bash
agentkodex tournament \
  --agents codex,claude-code,aider \
  --mode supervised \
  --task "Fix the failing auth tests" \
  --gates test,build
```

Agentkodex copies your repo into isolated temp workspaces, executes each selected adapter, runs gates, and writes a scorecard under `.agentkodex/runs/<run-id>/tournament.json`.

## Supported adapters

| Adapter | Executable(s) detected | How it runs |
|---|---|---|
| `codex` | `codex` | launches interactive CLI and sends mission prompt |
| `claude-code` | `claude` | launches interactive CLI and sends mission prompt |
| `aider` | `aider` | launches interactive CLI and sends mission prompt |
| `gemini` | `gemini` | launches interactive CLI and sends mission prompt |
| `opencode` | `opencode` | launches interactive CLI and sends mission prompt |
| `cursor` | `cursor-agent`, `cursor` | launches interactive CLI and sends mission prompt |
| `custom` | provided with `--custom-command` | launches the exact command |
| `shell` | system shell | runs `--shell-command` or quality gates only |

Agentkodex does not bundle paid/proprietary coding agents. Install your preferred CLI agents separately, then Agentkodex controls them through the terminal.

## Project memory

Agentkodex writes this structure into the target repo:

```text
.agentkodex/
  config.json
  policy.json
  project.kodex.md
  commands.kodex.yaml
  commands.kodex.json
  errors.kodex.json
  prompts/
  runs/
```

Every run stores:

```text
.agentkodex/runs/<run-id>/
  run.json
  task.md
  prompt.md
  transcript.txt
  commands.log
  diff.patch
  qa_report.json
  security_report.md
  summary.md
```

## Safety model

Agentkodex has four modes:

- `observe`: read-only workflow; no agent mutation intended.
- `supervised`: safe commands run; risky commands require approval unless `--yes` is passed.
- `sandbox-auto`: broader command allowance for disposable containers or temp copies.
- `trusted-auto`: broad local automation; destructive/production commands still blocked.

Commands are classified as:

- `safe`
- `approval_required`
- `blocked`

The default policy blocks dangerous patterns like `rm -rf /`, production database resets, reading common credential directories, broad permission changes, and curl-pipe-shell patterns.

## Important limitations

Agentkodex is a harness. It needs a real external coding agent CLI to perform intelligent code editing. The included `shell` adapter is useful for smoke testing, scripted workflows, and verifying that the harness, policy engine, PTY runner, and logging pipeline are working.

## Development

Run tests:

```bash
python -m unittest discover -s tests -v
```

Run a local smoke test:

```bash
python -m agentkodex doctor
python -m agentkodex init --repo /path/to/project
python -m agentkodex discover --repo /path/to/project
```
