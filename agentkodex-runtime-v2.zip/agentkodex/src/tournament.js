'use strict';

const fs = require('fs');
const path = require('path');
const { runTask } = require('./run');
const { ensureKodex, kodexPath } = require('./kodexStore');
const { copyDirFiltered, ensureDir, timestampId, slugify, writeJson, writeText } = require('./utils');

async function runTournament(options) {
  const root = path.resolve(options.root || process.cwd());
  const task = String(options.task || '').trim();
  const agents = options.agents || [];
  if (!task) throw new Error('Missing task. Example: agentkodex tournament --agents codex,claude-code "Fix failing tests"');
  if (!agents.length) throw new Error('Missing agents. Example: --agents codex,claude-code');

  ensureKodex(root);
  const id = `${timestampId()}-${slugify(task, 40)}`;
  const tournamentDir = kodexPath(root, 'tournaments', id);
  ensureDir(tournamentDir);

  const results = [];
  for (const agent of agents) {
    const workDir = path.join(tournamentDir, 'workspaces', agent);
    copyDirFiltered(root, workDir, { ignore: ['.git', 'node_modules', '.agentkodex', 'dist', 'coverage', '.next', '.turbo'] });
    const run = await runTask({
      root: workDir,
      task,
      agent,
      mode: options.mode || 'sandbox_auto',
      gates: options.gates || ['lint', 'test', 'build'],
      yes: true,
      timeoutMs: options.timeoutMs,
      echo: options.echo,
      pty: options.pty,
    });
    const score = scoreRun(run);
    results.push({ agent, score, runDir: run.dir, status: run.status.status, qa: run.qa, security: run.security });
  }

  results.sort((a, b) => b.score.total - a.score.total);
  const summary = { id, task, createdAt: new Date().toISOString(), results, winner: results[0]?.agent || null };
  writeJson(path.join(tournamentDir, 'scoreboard.json'), summary);
  writeText(path.join(tournamentDir, 'scoreboard.md'), renderTournament(summary));
  if (options.echo !== false) {
    console.log(renderTournament(summary));
    console.log(`Tournament directory: ${tournamentDir}`);
  }
  return summary;
}

function scoreRun(run) {
  const passed = run.gateResults.filter((g) => g.result && g.result.exitCode === 0).length;
  const failed = run.gateResults.filter((g) => g.result && g.result.exitCode !== 0 && !g.result.skipped).length;
  const criticalSecurity = (run.security.findings || []).filter((f) => ['critical', 'high'].includes(f.severity)).length;
  const qaPass = run.qa.pass ? 1 : 0;
  const total = passed * 25 + qaPass * 30 - failed * 30 - criticalSecurity * 50;
  return { total, passed, failed, criticalSecurity, qaPass };
}

function renderTournament(summary) {
  const lines = [];
  lines.push('# Agentkodex Tournament Scoreboard');
  lines.push('');
  lines.push(`Task: ${summary.task}`);
  lines.push(`Winner: ${summary.winner || 'none'}`);
  lines.push('');
  lines.push('| Rank | Agent | Score | Status | Passed | Failed | Security High/Critical | Run |');
  lines.push('|---:|---|---:|---|---:|---:|---:|---|');
  summary.results.forEach((item, index) => {
    lines.push(`| ${index + 1} | ${item.agent} | ${item.score.total} | ${item.status} | ${item.score.passed} | ${item.score.failed} | ${item.score.criticalSecurity} | ${item.runDir} |`);
  });
  lines.push('');
  return lines.join('\n');
}

module.exports = {
  runTournament,
  scoreRun,
  renderTournament,
};
