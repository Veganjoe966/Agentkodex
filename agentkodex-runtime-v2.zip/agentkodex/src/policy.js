'use strict';

const BLOCKED_PATTERNS = [
  /\brm\s+-rf\s+\//i,
  /\brm\s+-rf\s+~\b/i,
  /\brm\s+-rf\s+\$HOME\b/i,
  /\bsudo\b/i,
  /\bchmod\s+-R\s+777\b/i,
  /\bchown\s+-R\b/i,
  /\bmkfs\b/i,
  /\bdd\s+if=/i,
  /\bshutdown\b/i,
  /\breboot\b/i,
  /\b:(){\s*:|:&\s*};:/,
  /\bcat\s+~\/\.ssh\//i,
  /\bcat\s+~\/\.aws\//i,
  /\bcat\s+\.env(\s|$)/i,
  /\bcurl\b.+\|\s*(sh|bash)/i,
  /\bwget\b.+\|\s*(sh|bash)/i,
];

const APPROVAL_PATTERNS = [
  /\b(npm|pnpm|yarn|bun)\s+(install|add|remove|update|upgrade)\b/i,
  /\b(pip|pipx|uv|poetry)\s+(install|add|remove|sync)\b/i,
  /\bbrew\s+(install|upgrade|remove)\b/i,
  /\bdocker\s+(compose\s+)?up\b/i,
  /\bdocker\s+(build|run|pull|push|system)\b/i,
  /\bgit\s+(commit|push|reset|clean|checkout|merge|rebase)\b/i,
  /\bgh\s+pr\s+create\b/i,
  /\b(vercel|netlify|fly|railway|wrangler|firebase)\s+(deploy|publish)\b/i,
  /\bprisma\s+migrate\b/i,
  /\brails\s+db:/i,
  /\bsequelize\s+db:/i,
];

const SAFE_PATTERNS = [
  /^\s*(pwd|ls|find|rg|grep|cat|sed|awk|head|tail|wc|git status|git diff|git log|git branch)\b/i,
  /\b(npm|pnpm|yarn|bun)\s+(run\s+)?(test|lint|build|typecheck|check)\b/i,
  /\bgo\s+(test|build)\b/i,
  /\bcargo\s+(test|build|clippy|fmt)\b/i,
  /\bpytest\b/i,
  /\bruff\s+check\b/i,
  /\bmake\s+(test|lint|build|check)\b/i,
];

function classifyCommand(command) {
  const value = String(command || '').trim();
  if (!value) return { risk: 'safe', reason: 'empty command' };

  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(value)) return { risk: 'blocked', reason: `matched blocked pattern ${pattern}` };
  }
  for (const pattern of APPROVAL_PATTERNS) {
    if (pattern.test(value)) return { risk: 'approval_required', reason: `matched approval pattern ${pattern}` };
  }
  for (const pattern of SAFE_PATTERNS) {
    if (pattern.test(value)) return { risk: 'safe', reason: `matched safe pattern ${pattern}` };
  }
  return { risk: 'unknown', reason: 'no matching policy pattern' };
}

function policyAllows(command, options = {}) {
  const mode = normalizeMode(options.mode || 'supervised');
  const yes = Boolean(options.yes || options.autoApprove);
  const agentLaunch = Boolean(options.agentLaunch);
  const classification = classifyCommand(command);

  if (classification.risk === 'blocked') {
    return { allowed: false, requiresApproval: false, classification, reason: 'Blocked by Agentkodex command policy' };
  }

  if (mode === 'observe') {
    return { allowed: false, requiresApproval: true, classification, reason: 'Observe mode does not execute commands' };
  }

  if (agentLaunch) {
    return { allowed: true, requiresApproval: false, classification, reason: 'Allowed as coding-agent CLI launch' };
  }

  if (classification.risk === 'approval_required' || classification.risk === 'unknown') {
    if (mode === 'trusted_auto' || mode === 'sandbox_auto' || yes) {
      return { allowed: true, requiresApproval: false, classification, reason: 'Approved by mode or --yes' };
    }
    return { allowed: false, requiresApproval: true, classification, reason: 'Command requires approval. Re-run with --yes or trusted/sandbox mode.' };
  }

  return { allowed: true, requiresApproval: false, classification, reason: 'Allowed by policy' };
}

function normalizeMode(mode) {
  return String(mode || 'supervised').replace(/-/g, '_');
}

function redactSecrets(text) {
  if (!text) return '';
  return String(text)
    .replace(/(sk-[A-Za-z0-9_-]{12,})/g, '[REDACTED_OPENAI_STYLE_KEY]')
    .replace(/(ghp_[A-Za-z0-9_]{20,})/g, '[REDACTED_GITHUB_TOKEN]')
    .replace(/(xox[baprs]-[A-Za-z0-9-]{20,})/g, '[REDACTED_SLACK_TOKEN]')
    .replace(/((?:AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|DATABASE_URL|API_KEY|SECRET|TOKEN|PASSWORD)=)[^\s]+/gi, '$1[REDACTED]')
    .replace(/-----BEGIN [A-Z ]+PRIVATE KEY-----[\s\S]*?-----END [A-Z ]+PRIVATE KEY-----/g, '[REDACTED_PRIVATE_KEY]');
}

module.exports = {
  classifyCommand,
  policyAllows,
  redactSecrets,
  BLOCKED_PATTERNS,
  APPROVAL_PATTERNS,
  SAFE_PATTERNS,
  normalizeMode,
};
