'use strict';

const path = require('path');
const { parseArgs, stringFlag, listFlag, booleanFlag } = require('./args');
const { discoverProject, selectCommands } = require('./discovery');
const { ensureKodex, loadConfig, saveConfig, saveDiscovery, kodexPath } = require('./kodexStore');
const { renderAgentTable, setAgentCommand, detectAgent, recommendAgents } = require('./agents');
const { runTask } = require('./run');
const { runTournament } = require('./tournament');
const { renderRunHtml, resolveRun } = require('./report');
const { readText, readJson, exists } = require('./utils');
const { createTaskBrief, createPlan } = require('./prompts');
const { daemonCommand, sessionCommand, approvalsCommand } = require('./runtimeCli');
const { cockpitCommand } = require('./cockpit');

async function main(argv) {
  const [command = 'help', ...rest] = argv;
  switch (command) {
    case 'init':
      return initCommand(rest);
    case 'discover':
      return discoverCommand(rest);
    case 'run':
      return runCommand(rest);
    case 'tournament':
      return tournamentCommand(rest);
    case 'replay':
      return replayCommand(rest);
    case 'status':
      return statusCommand(rest);
    case 'report':
      return reportCommand(rest);
    case 'daemon':
      return daemonCommand(rest);
    case 'cockpit':
      return cockpitCommand(rest);
    case 'session':
    case 'sessions':
      return sessionCommand(rest);
    case 'attach':
      return sessionCommand(['attach', ...rest]);
    case 'approvals':
    case 'approval':
      return approvalsCommand(rest);
    case 'approve':
      return approvalsCommand(['approve', ...rest]);
    case 'deny':
      return approvalsCommand(['deny', ...rest]);
    case 'agents':
      return agentsCommand(rest);
    case 'policy':
      return policyCommand(rest);
    case 'suggest':
      return suggestCommand(rest);
    case 'plan':
      return planCommand(rest);
    case 'kodex':
      return kodexCommand(rest);
    case 'doctor':
      return doctorCommand(rest);
    case 'help':
    case '--help':
    case '-h':
      console.log(helpText());
      return;
    case 'version':
    case '--version':
    case '-v':
      console.log(require('../package.json').version);
      return;
    default:
      console.error(`Unknown command: ${command}`);
      console.log(helpText());
      process.exitCode = 1;
  }
}

function cwdFromFlags(flags) {
  return path.resolve(stringFlag(flags, 'cwd', stringFlag(flags, 'repo', process.cwd())));
}

function hasFlag(flags, name) {
  return Object.prototype.hasOwnProperty.call(flags, name);
}

async function initCommand(argv) {
  const { flags } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const base = ensureKodex(root);
  const discovery = discoverProject(root);
  saveDiscovery(root, discovery);
  console.log(`Initialized Agentkodex at ${base}`);
  console.log(`Discovered ${discovery.commands.length} commands.`);
}

async function discoverCommand(argv) {
  const { flags } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  ensureKodex(root);
  const discovery = discoverProject(root);
  saveDiscovery(root, discovery);
  if (booleanFlag(flags, 'json')) console.log(JSON.stringify(discovery, null, 2));
  else {
    console.log(`Project: ${discovery.projectName}`);
    console.log(`Languages: ${discovery.languages.join(', ') || 'unknown'}`);
    console.log(`Frameworks: ${discovery.frameworks.join(', ') || 'unknown'}`);
    console.log(`Package manager: ${discovery.packageManager || 'unknown'}`);
    console.log('Commands:');
    for (const command of discovery.commands) console.log(`- ${command.name}: ${command.command} (${command.evidence})`);
    console.log(`Saved: ${kodexPath(root, 'project.kodex.md')}`);
  }
}

async function runCommand(argv) {
  const { flags, positionals } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const task = positionals.join(' ').trim() || stringFlag(flags, 'task', '');
  const runtime = stringFlag(flags, 'runtime', 'oneshot');
  const cockpit = booleanFlag(flags, 'cockpit') || booleanFlag(flags, 'session') || ['session', 'interactive', 'cockpit', 'runtime-v2'].includes(runtime);

  if (cockpit) {
    return sessionCommand(['start', ...argv.filter((x) => x !== '--cockpit' && x !== '--session')]);
  }

  const result = await runTask({
    root,
    task,
    agent: stringFlag(flags, 'agent', ''),
    mode: stringFlag(flags, 'mode', ''),
    gates: hasFlag(flags, 'gates') ? listFlag(flags, 'gates', []) : undefined,
    yes: booleanFlag(flags, 'yes') || booleanFlag(flags, 'y'),
    command: stringFlag(flags, 'command', '') || stringFlag(flags, 'shellCommand', stringFlag(flags, 'shell-command', '')) || stringFlag(flags, 'customCommand', stringFlag(flags, 'custom-command', '')),
    skipAgent: booleanFlag(flags, 'skipAgent') || booleanFlag(flags, 'skip-agent'),
    timeoutMs: Number(stringFlag(flags, 'timeoutMs', stringFlag(flags, 'timeout-ms', '0')) || 0) || undefined,
    echo: !booleanFlag(flags, 'quiet'),
    pty: booleanFlag(flags, 'pty'),
  });
  if (booleanFlag(flags, 'json')) console.log(JSON.stringify(result.status, null, 2));
}

async function tournamentCommand(argv) {
  const { flags, positionals } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const task = positionals.join(' ').trim() || stringFlag(flags, 'task', '');
  await runTournament({
    root,
    task,
    agents: listFlag(flags, 'agents', []),
    mode: stringFlag(flags, 'mode', 'sandbox_auto'),
    gates: hasFlag(flags, 'gates') ? listFlag(flags, 'gates', []) : undefined,
    timeoutMs: Number(stringFlag(flags, 'timeoutMs', stringFlag(flags, 'timeout-ms', '0')) || 0) || undefined,
    echo: !booleanFlag(flags, 'quiet'),
    pty: booleanFlag(flags, 'pty'),
  });
}

async function replayCommand(argv) {
  const { flags, positionals } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const run = resolveRun(root, positionals[0] || 'last');
  if (!run) throw new Error('No Agentkodex run found.');
  const file = path.join(run.dir, 'transcript.log');
  console.log(readText(file, '(no transcript)'));
}

async function statusCommand(argv) {
  const { flags, positionals } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const run = resolveRun(root, positionals[0] || 'last');
  if (!run) throw new Error('No Agentkodex run found.');
  const status = readJson(path.join(run.dir, 'status.json'), {});
  if (booleanFlag(flags, 'json')) console.log(JSON.stringify(status, null, 2));
  else {
    console.log(`Run: ${run.id}`);
    console.log(`Status: ${status.status || 'unknown'}`);
    console.log(`Task: ${status.task || ''}`);
    console.log(`Agent: ${status.agent || ''}`);
    console.log(`Mode: ${status.mode || ''}`);
    console.log(`Runtime: ${status.runtime || 'oneshot'}`);
    console.log(`Directory: ${run.dir}`);
  }
}

async function reportCommand(argv) {
  const { flags, positionals } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const out = renderRunHtml(root, positionals[0] || 'last');
  console.log(`Report: ${out}`);
}

async function agentsCommand(argv) {
  const [sub = 'list', ...rest] = argv;
  const { flags, positionals } = parseArgs(rest);
  const root = cwdFromFlags(flags);
  ensureKodex(root);
  const config = loadConfig(root);

  if (sub === 'list') {
    console.log(renderAgentTable(config));
    return;
  }

  if (sub === 'detect') {
    const id = positionals[0] || stringFlag(flags, 'agent', config.defaultAgent || 'local');
    const detection = await detectAgent(config, id, { customCommand: stringFlag(flags, 'customCommand', stringFlag(flags, 'custom-command', '')) });
    console.log(JSON.stringify(detection, null, 2));
    return;
  }

  if (sub === 'set') {
    const id = positionals[0] || stringFlag(flags, 'agent', 'custom');
    const cmd = stringFlag(flags, 'cmd', stringFlag(flags, 'command', ''));
    if (!cmd) throw new Error('Missing --cmd. Example: agentkodex agents set custom --cmd "your-cli {promptFile}"');
    const stdin = flags.stdin === undefined ? null : booleanFlag(flags, 'stdin');
    setAgentCommand(config, id, cmd, stdin);
    saveConfig(root, config);
    console.log(`Saved agent ${id}: ${cmd}`);
    return;
  }

  throw new Error(`Unknown agents subcommand: ${sub}`);
}

async function policyCommand(argv) {
  const { classifyCommand, policyAllows } = require('./policy');
  const { flags, positionals } = parseArgs(argv);
  const command = positionals.join(' ') || stringFlag(flags, 'command', '');
  if (!command) throw new Error('Missing command to classify.');
  const classification = classifyCommand(command);
  const decision = policyAllows(command, { mode: stringFlag(flags, 'mode', 'supervised'), yes: booleanFlag(flags, 'yes') });
  console.log(JSON.stringify({ command, classification, decision }, null, 2));
}

async function suggestCommand(argv) {
  const { flags, positionals } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const task = positionals.join(' ').trim() || stringFlag(flags, 'task', '');
  const discovery = discoverProject(root);
  const recommendations = recommendAgents(task, discovery);
  if (booleanFlag(flags, 'json')) console.log(JSON.stringify({ task, recommendations }, null, 2));
  else {
    console.log(`Recommended Agentkodex agents for: ${task || '(no task provided)'}`);
    recommendations.forEach((item, index) => console.log(`${index + 1}. ${item.agent} — ${item.reason}`));
  }
}

async function planCommand(argv) {
  const { flags, positionals } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  const task = positionals.join(' ').trim() || stringFlag(flags, 'task', '');
  if (!task) throw new Error('Missing task. Example: agentkodex plan "Add password reset"');
  const discovery = discoverProject(root);
  const gates = listFlag(flags, 'gates', ['lint', 'test', 'build']);
  const selected = gates.includes('none') ? [] : selectCommands(discovery, gates);
  const brief = createTaskBrief(task, discovery, { gates, agent: stringFlag(flags, 'agent', 'local'), mode: stringFlag(flags, 'mode', 'supervised') });
  const plan = createPlan(task, discovery, selected, { agent: stringFlag(flags, 'agent', 'local'), mode: stringFlag(flags, 'mode', 'supervised') });
  if (booleanFlag(flags, 'json')) console.log(JSON.stringify({ taskBrief: brief, plan }, null, 2));
  else console.log(`${brief}\n${plan}`);
}

async function kodexCommand(argv) {
  const [sub = 'show', ...rest] = argv;
  const { flags } = parseArgs(rest);
  const root = cwdFromFlags(flags);
  ensureKodex(root);
  if (sub === 'show') {
    console.log(readText(kodexPath(root, 'project.kodex.md'), '(no project Kodex yet; run agentkodex discover)'));
    return;
  }
  if (sub === 'path') {
    console.log(kodexPath(root));
    return;
  }
  throw new Error(`Unknown kodex subcommand: ${sub}`);
}

async function doctorCommand(argv) {
  const { flags } = parseArgs(argv);
  const root = cwdFromFlags(flags);
  ensureKodex(root);
  const config = loadConfig(root);
  const { pingDaemon } = require('./runtime/client');
  const { listSessionStatuses } = require('./runtime/sessionManager');
  console.log('Agentkodex doctor');
  console.log(`root: ${root}`);
  console.log(`node: ${process.version}`);
  console.log(`package: ${require('../package.json').version}`);
  console.log(`kodex: ${kodexPath(root)}`);
  const sessions = listSessionStatuses(root);
  const live = sessions.filter((session) => session.live);
  console.log(`runtime: Runtime v2 per-session supervisors`);
  console.log(`sessions: ${sessions.length} total, ${live.length} live`);
  const daemon = await pingDaemon(root);
  console.log(`compat daemon: ${daemon ? `running pid=${daemon.pid}` : 'not running/not required'}`);
  console.log('agents:');
  for (const id of Object.keys(config.agents || {})) {
    const detection = await detectAgent(config, id);
    console.log(`- ${id}: ${detection.installed ? 'available' : 'missing'}${detection.binary ? ` (${detection.binary})` : ''}`);
  }
  if (!exists(kodexPath(root, 'commands.kodex.json'))) console.log('hint: run agentkodex discover to populate project command memory.');
}

function helpText() {
  return `Agentkodex — CLI-native agent harness for autonomous software delivery.

Usage:
  agentkodex init [--cwd path]
  agentkodex discover [--json] [--cwd path]
  agentkodex plan "task"
  agentkodex suggest "task"
  agentkodex run [options] "task"
  agentkodex run --runtime cockpit [options] "task"
  agentkodex daemon start|stop|status|logs
  agentkodex cockpit [--port 3919] [--host 127.0.0.1] [--once|--json]
  agentkodex session start|list|status|send|attach|interrupt|kill|replay|gates|finalize
  agentkodex approvals list|approve|deny
  agentkodex approve <approval-id> / deny <approval-id>
  agentkodex tournament --agents codex,claude-code "task"
  agentkodex replay [last|run-id]
  agentkodex status [last|run-id] [--json]
  agentkodex report [last|run-id]
  agentkodex agents list
  agentkodex agents detect <agent>
  agentkodex agents set <agent> --cmd "your-cli {promptFile}" [--stdin true]
  agentkodex policy "command to classify"
  agentkodex kodex show
  agentkodex doctor

Run options:
  --agent <id>          local, shell, codex, claude-code, aider, gemini, opencode, cursor, custom
  --mode <mode>         observe, supervised, sandbox_auto, trusted_auto
  --gates <list>        comma list such as lint,test,build or none
  --command <cmd>       run an explicit implementation command instead of agent template
  --custom-command      one-off custom agent command/template
  --shell-command       one-off shell adapter command
  --runtime cockpit     start a persistent Runtime v2 agent cockpit session
  --cockpit             alias for --runtime cockpit
  --skip-agent          skip implementation phase and run only discovery/gates/reports
  --yes                 auto-approve unknown/risky non-blocked commands
  --pty                 wrap command with script(1) pseudo-terminal when available
  --wait                with session start, wait for exit and auto-finalize
  --no-finalize         with session start --wait, skip automatic gate finalization
  --quiet               reduce live output
  --cwd, --repo <path>  project root

Runtime v2 examples:
  agentkodex cockpit
  agentkodex cockpit --once
  agentkodex daemon start
  agentkodex session start --agent shell --command "node -e 'console.log(123)'" --mode sandbox_auto --yes --wait "Smoke test"
  agentkodex session start --agent claude-code --mode supervised "Add Clerk auth end to end"
  agentkodex session attach last
  agentkodex session send last "Run the test suite now"
  agentkodex session status last --watch
  agentkodex session finalize last --gates test,build --yes
  agentkodex cockpit --port 3919
  agentkodex approvals list
  agentkodex approvals approve last

Command template variables:
  {promptFile} {prompt} {cwd} {runDir} {task}

Examples:
  agentkodex init
  agentkodex agents set custom --cmd "my-agent --file {promptFile}"
  agentkodex run --agent custom --mode sandbox_auto --gates lint,test,build "Add password reset"
  agentkodex run --skip-agent --gates test "Verify current repo"
`;
}

module.exports = { main, helpText };
