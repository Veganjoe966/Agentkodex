'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  ensureDir,
  exists,
  readJson,
  readText,
  writeJson,
  writeText,
  appendText,
  timestampId,
  hashString,
} = require('../utils');
const { ensureKodex, kodexPath } = require('../kodexStore');

function runtimeDir(root) {
  ensureKodex(root);
  const dir = kodexPath(root, 'runtime');
  ensureDir(dir);
  return dir;
}

function sessionsDir(root) {
  ensureKodex(root);
  const dir = kodexPath(root, 'sessions');
  ensureDir(dir);
  return dir;
}

function sessionDir(root, sessionId) {
  const dir = path.join(sessionsDir(root), sessionId);
  ensureDir(dir);
  return dir;
}

function socketPathForRoot(root) {
  const key = hashString(path.resolve(root), 20);
  if (process.platform === 'win32') return `\\\\.\\pipe\\agentkodex-${key}`;
  return path.join(os.tmpdir(), `agentkodex-${key}.sock`);
}

function makeSocketPath(root, sessionId) {
  const key = hashString(path.resolve(root), 20);
  if (process.platform === 'win32') return `\\\\.\\pipe\\agentkodex-${key}-${sessionId}`;
  return path.join(os.tmpdir(), `agentkodex-${key}-${sessionId}.sock`);
}

function daemonInfoPath(root) {
  return path.join(runtimeDir(root), 'daemon.json');
}

function daemonLogPath(root) {
  return path.join(runtimeDir(root), 'daemon.log');
}

function readDaemonInfo(root) {
  return readJson(daemonInfoPath(root), null);
}

function writeDaemonInfo(root, info) {
  writeJson(daemonInfoPath(root), {
    ...info,
    root: path.resolve(root),
    socketPath: socketPathForRoot(root),
    logPath: daemonLogPath(root),
    updatedAt: new Date().toISOString(),
  });
}

function newSessionId(seed = '') {
  return `sess_${timestampId()}_${hashString(`${seed}:${process.pid}:${Date.now()}:${Math.random()}`, 8)}`;
}

function sessionFiles(root, id, runDir = null) {
  const dir = sessionDir(root, id);
  const base = runDir || dir;
  ensureDir(base);
  ensureDir(dir);
  return {
    session: path.join(dir, 'session.json'),
    metadata: path.join(dir, 'metadata.json'),
    transcript: path.join(base, 'transcript.log'),
    events: path.join(base, 'session-events.ndjson'),
    commands: path.join(base, 'commands.log'),
    policy: path.join(base, 'policy.log'),
    approvals: path.join(dir, 'approvals.json'),
    inbox: path.join(dir, 'inbox.ndjson'),
    input: path.join(base, 'input.log'),
    workerLog: path.join(dir, 'worker.log'),
    supervisor: path.join(dir, 'supervisor.log'),
  };
}

function normalizeRecord(root, data = {}) {
  const id = data.id || newSessionId(`${data.agent || ''}:${data.task || ''}:${data.command || ''}`);
  const dir = sessionDir(root, id);
  const runDir = data.runDir || dir;
  const now = new Date().toISOString();
  const files = { ...sessionFiles(root, id, runDir), ...(data.files || {}) };
  return {
    id,
    root: path.resolve(data.root || root),
    dir,
    sessionDir: dir,
    runDir,
    runId: data.runId || null,
    task: data.task || '',
    agent: data.agent || 'custom',
    adapterKind: data.adapterKind || data.runtime || 'template',
    command: data.command || '',
    cwd: path.resolve(data.cwd || root),
    mode: data.mode || 'supervised',
    gates: data.gates || [],
    status: data.status || 'created',
    state: data.state || 'starting',
    pid: data.pid || null,
    childPid: data.childPid || null,
    workerPid: data.workerPid || null,
    supervisorPid: data.supervisorPid || null,
    workerLauncherPid: data.workerLauncherPid || null,
    pty: Boolean(data.pty || data.usePty),
    usePty: Boolean(data.usePty || data.pty),
    terminalKind: data.terminalKind || null,
    capabilities: data.capabilities || {},
    policy: data.policy || null,
    approvals: Array.isArray(data.approvals) ? data.approvals : [],
    openApprovalId: data.openApprovalId || null,
    pendingStart: data.pendingStart || null,
    promptFile: data.promptFile || files.missionPrompt || null,
    socketPath: data.socketPath || makeSocketPath(root, id),
    metadata: data.metadata || {},
    files,
    createdAt: data.createdAt || now,
    updatedAt: data.updatedAt || now,
    startedAt: data.startedAt || null,
    endedAt: data.endedAt || data.completedAt || null,
    completedAt: data.completedAt || null,
    heartbeatAt: data.heartbeatAt || null,
    lastOutputAt: data.lastOutputAt || null,
    lastStateReason: data.lastStateReason || '',
    lastInboxSeq: Number(data.lastInboxSeq || 0),
    exitCode: data.exitCode === undefined ? null : data.exitCode,
    signal: data.signal || null,
    error: data.error || null,
  };
}

function createSession(root, data = {}) {
  const record = normalizeRecord(root, data);
  saveSessionRecord(root, record);
  writeText(kodexPath(root, 'last-session'), record.id);
  appendEvent(root, record.id, { type: 'session.created', agent: record.agent, task: record.task, command: record.command });
  return record;
}

function createSessionRecord(root, data = {}) {
  return createSession(root, data);
}

function saveSessionRecord(root, record) {
  const normalized = normalizeRecord(root, { ...record, id: record.id, createdAt: record.createdAt });
  normalized.updatedAt = new Date().toISOString();
  ensureDir(path.dirname(normalized.files.session));
  writeJson(normalized.files.session, normalized);
  writeJson(normalized.files.metadata, normalized);
  writeText(kodexPath(root, 'last-session'), normalized.id);
  return normalized;
}

function saveSession(session, patch = {}) {
  if (!session) throw new Error('Missing session to save.');
  return saveSessionRecord(session.root, { ...session, ...patch });
}

function resolveSessionId(root, idOrLast = 'last') {
  ensureKodex(root);
  const raw = String(idOrLast || 'last');
  if (raw === 'last') {
    const last = readText(kodexPath(root, 'last-session'), '').trim();
    if (last && exists(path.join(sessionDir(root, last), 'session.json'))) return last;
    const sessions = listSessions(root);
    return sessions.length ? sessions[0].id : null;
  }
  if (exists(path.join(sessionDir(root, raw), 'session.json'))) return raw;
  const matches = listSessions(root).filter((session) => session.id.startsWith(raw));
  return matches.length === 1 ? matches[0].id : null;
}

function loadSessionRecord(root, idOrLast = 'last') {
  const id = resolveSessionId(root, idOrLast);
  if (!id) return null;
  const record = readJson(path.join(sessionDir(root, id), 'session.json'), null);
  return record ? refreshSessionLiveness(record) : null;
}

function getSession(root, idOrLast = 'last') {
  return loadSessionRecord(root, idOrLast);
}

function loadSession(root, idOrLast = 'last') {
  return loadSessionRecord(root, idOrLast);
}

function readSession(root, idOrLast = 'last') {
  return loadSessionRecord(root, idOrLast);
}

function writeSession(root, session) {
  return saveSessionRecord(root, session);
}

function updateSession(root, idOrLast, patch = {}) {
  const existing = loadSessionRecord(root, idOrLast);
  if (!existing) throw new Error(`Unknown session: ${idOrLast}`);
  return saveSessionRecord(root, { ...existing, ...patch });
}

function patchSession(root, idOrLast, patch = {}) {
  return updateSession(root, idOrLast, patch);
}

function resolveSession(root, idOrLast = 'last') {
  return loadSessionRecord(root, idOrLast);
}

function listSessions(root, options = {}) {
  const dir = sessionsDir(root);
  if (!exists(dir)) return [];
  const rows = fs.readdirSync(dir)
    .map((id) => readJson(path.join(dir, id, 'session.json'), null))
    .filter(Boolean)
    .map(refreshSessionLiveness)
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  if (options.status) return rows.filter((row) => row.status === options.status || row.state === options.status);
  return rows;
}

function listSessionRecords(root, options = {}) {
  return listSessions(root, options);
}

function sessionSummary(session) {
  return {
    id: session.id,
    status: session.status,
    state: session.state,
    agent: session.agent,
    task: session.task,
    pid: session.pid,
    childPid: session.childPid,
    workerPid: session.workerPid,
    runId: session.runId,
    runDir: session.runDir,
    sessionDir: session.sessionDir || session.dir,
    createdAt: session.createdAt,
    updatedAt: session.updatedAt,
  };
}

function publicSession(record) {
  if (!record) return null;
  return {
    ...record,
    approvals: record.approvals || [],
    pendingApprovals: (record.approvals || []).filter((item) => ['pending', 'open'].includes(item.status)).length,
  };
}

function appendEvent(arg1, arg2, arg3) {
  let root;
  let id;
  let event;
  if (typeof arg1 === 'object' && arg1 && arg1.id) {
    root = arg1.root;
    id = arg1.id;
    event = arg2 || {};
  } else {
    root = arg1;
    id = arg2;
    event = arg3 || {};
  }
  const record = loadSessionRecord(root, id) || normalizeRecord(root, { id });
  const payload = { ts: new Date().toISOString(), timestamp: new Date().toISOString(), sessionId: id, ...event };
  appendText(record.files.events, `${JSON.stringify(payload)}\n`);
  return payload;
}

function appendSessionEvent(session, event) {
  return appendEvent(session, event);
}

function appendTranscript(arg1, arg2, arg3) {
  let root;
  let id;
  let text;
  if (typeof arg1 === 'object' && arg1 && arg1.id) {
    root = arg1.root;
    id = arg1.id;
    text = arg2;
  } else {
    root = arg1;
    id = arg2;
    text = arg3;
  }
  const record = loadSessionRecord(root, id) || normalizeRecord(root, { id });
  appendText(record.files.transcript, String(text || ''));
}

function appendInput(root, id, data) {
  const record = loadSessionRecord(root, id) || normalizeRecord(root, { id });
  appendText(record.files.input, String(data || ''));
  appendEvent(root, id, { type: 'input.logged', bytes: Buffer.byteLength(String(data || '')) });
}

function writePrompt(session, text) {
  const file = session.promptFile || path.join(session.sessionDir || session.dir, 'prompt.md');
  writeText(file, text);
  return file;
}

function appendInbox(session, type, payload = {}) {
  const current = loadSessionRecord(session.root, session.id) || session;
  const seq = Number(current.lastInboxWrittenSeq || 0) + 1;
  const item = { seq, ts: new Date().toISOString(), type, payload };
  appendText(current.files.inbox, `${JSON.stringify(item)}\n`);
  saveSessionRecord(current.root, { ...current, lastInboxWrittenSeq: seq });
  return item;
}

function readInbox(session, afterSeq = 0) {
  const current = loadSessionRecord(session.root, session.id) || session;
  if (!exists(current.files.inbox)) return [];
  return readText(current.files.inbox)
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => {
      try { return JSON.parse(line); } catch (_) { return null; }
    })
    .filter((item) => item && Number(item.seq || 0) > Number(afterSeq || 0));
}

function readApprovals(root, sessionId) {
  const session = loadSessionRecord(root, sessionId);
  const file = session?.files?.approvals || path.join(sessionDir(root, sessionId), 'approvals.json');
  const value = readJson(file, { approvals: [] });
  if (Array.isArray(value)) return value;
  return value.approvals || [];
}

function saveApprovals(root, sessionId, approvals) {
  const session = loadSessionRecord(root, sessionId);
  const file = session?.files?.approvals || path.join(sessionDir(root, sessionId), 'approvals.json');
  writeJson(file, { approvals: Array.isArray(approvals) ? approvals : [] });
}

function addApproval(root, record, approval = {}) {
  const current = loadSessionRecord(root, record.id) || record;
  const id = approval.id || `appr_${hashString(`${current.id}:${approval.signature || approval.prompt || approval.command || Date.now()}`, 10)}`;
  const existing = (current.approvals || []).find((item) => item.id === id || (approval.signature && item.signature === approval.signature));
  if (existing && ['pending', 'open'].includes(existing.status)) return existing;
  const item = {
    id,
    status: approval.status || 'pending',
    kind: approval.kind || 'terminal_prompt',
    command: approval.command || null,
    prompt: approval.prompt || '',
    reason: approval.reason || 'Terminal prompt detected.',
    suggestedResponse: approval.suggestedResponse || approval.defaultApproveInput || 'y',
    signature: approval.signature || id,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    decidedAt: null,
    decision: null,
  };
  current.approvals = [...(current.approvals || []), item];
  current.openApprovalId = item.id;
  saveSessionRecord(root, current);
  appendEvent(root, current.id, { type: 'approval.created', approval: item });
  return item;
}

function decideApproval(root, record, approvalId, decision) {
  const current = loadSessionRecord(root, record.id) || record;
  const approvals = current.approvals || [];
  const index = approvals.findIndex((item) => item.id === approvalId || item.id.startsWith(approvalId));
  if (index === -1) return null;
  const status = decision === 'approve' || decision === 'approved' ? 'approved' : 'denied';
  approvals[index] = {
    ...approvals[index],
    status,
    decision: status,
    decidedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  current.approvals = approvals;
  const pending = approvals.find((item) => ['pending', 'open'].includes(item.status));
  current.openApprovalId = pending ? pending.id : null;
  saveSessionRecord(root, current);
  appendEvent(root, current.id, { type: 'approval.decided', approval: approvals[index] });
  return approvals[index];
}

function archiveSession(root, id) {
  return loadSessionRecord(root, id);
}

function refreshSessionLiveness(session) {
  if (!session) return session;
  const live = isProcessAlive(session.pid) || isProcessAlive(session.childPid) || isProcessAlive(session.workerPid) || isProcessAlive(session.supervisorPid);
  if (['running', 'starting'].includes(session.status) && !live && session.exitCode !== null && session.exitCode !== undefined) {
    return { ...session, status: session.exitCode === 0 ? 'completed' : 'failed', state: session.exitCode === 0 ? 'completed' : 'failed' };
  }
  return session;
}

function isProcessAlive(pid) {
  if (!pid) return false;
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch (_) {
    return false;
  }
}

module.exports = {
  runtimeDir,
  sessionsDir,
  sessionDir,
  sessionFiles,
  socketPathForRoot,
  makeSocketPath,
  daemonInfoPath,
  daemonLogPath,
  readDaemonInfo,
  writeDaemonInfo,
  newSessionId,
  createSession,
  createSessionRecord,
  saveSession,
  saveSessionRecord,
  loadSession,
  loadSessionRecord,
  getSession,
  readSession,
  writeSession,
  updateSession,
  patchSession,
  resolveSession,
  resolveSessionId,
  listSessions,
  listSessionRecords,
  sessionSummary,
  publicSession,
  appendEvent,
  appendSessionEvent,
  appendTranscript,
  appendInput,
  appendInbox,
  readInbox,
  writePrompt,
  readApprovals,
  saveApprovals,
  addApproval,
  decideApproval,
  archiveSession,
  isProcessAlive,
  isPidAlive: isProcessAlive,
};
