# Agentkodex

**Agentkodex** is a local-first, CLI-native harness for autonomous software delivery. It lets you pick a coding-agent CLI — Codex, Claude Code, Aider, Gemini, OpenCode, Cursor, or a custom command — and run it inside a persistent project terminal workflow with logs, approvals, replay, gates, QA, security summaries, and a local Cockpit UI.

Agentkodex is not another app scaffold generator. It is the control layer around real CLIs.

## What is included in this build

This is a working Node.js CLI package with no required third-party runtime dependencies.

Implemented capabilities:

- `agentkodex init` project memory setup.
- `agentkodex discover` command discovery for Node, Python, Go, Rust, Ruby, Java, .NET, Makefile, Justfile, Taskfile, Docker, Compose, GitHub Actions, and env examples.
- Adapter registry for `local`, `shell`, `codex`, `claude-code`, `aider`, `gemini`, `opencode`, `cursor`, and `custom`.
- One-shot run mode with discovered quality gates, transcripts, policy logs, QA report, security report, diff capture, and final report.
- **Runtime v2 persistent sessions** with per-session supervisors, local sockets, transcript replay, event logs, send/interrupt/kill/finalize controls, and approval detection.
- **Agentkodex Cockpit**, a dependency-free local browser UI for sessions, transcripts, approvals, and live control.
- Approval queue for risky commands and terminal prompts.
- Tournament mode for comparing multiple agents on the same task in isolated repo copies.
- Policy engine with safe, approval-required, and blocked command categories.
- Secret redaction in logs.
- Test suite covering discovery, policy, one-shot runs, Runtime v2 sessions, daemon compatibility, Cockpit API, and command execution.

Agentkodex does **not** bundle paid or proprietary coding-agent CLIs. Install your preferred agents separately, then Agentkodex controls them through the terminal.

## Requirements

- Node.js 18+
- A Unix-like shell is recommended for best terminal behavior.
- Optional external coding agents on `PATH`, such as `codex`, `claude`, `aider`, `gemini`, `opencode`, or `cursor-agent`.

## Install locally

From this folder:

```bash
npm install
npm link
agentkodex --help
```

Or run without linking:

```bash
node bin/agentkodex.js --help
```

## Fast start

Inside any software project:

```bash
agentkodex init
agentkodex discover
agentkodex agents list
agentkodex run --skip-agent "Verify the project with discovered gates"
```

Run a persistent Runtime v2 session:

```bash
agentkodex run \
  --runtime cockpit \
  --agent shell \
  --command "npm test" \
  --mode sandbox_auto \
  --yes \
  --wait \
  "Run tests through Runtime v2"
```

Use a real coding agent CLI:

```bash
agentkodex run \
  --runtime cockpit \
  --agent claude-code \
  --mode supervised \
  --wait \
  "Add password reset and verify it end to end"
```

Configure a custom agent:

```bash
agentkodex agents set custom --cmd "my-agent --prompt-file {promptFile} --cwd {cwd}"
agentkodex run --runtime cockpit --agent custom "Build the billing settings page"
```

## Runtime v2 commands

```bash
agentkodex session start --agent shell --command "node -e 'console.log(123)'" --mode sandbox_auto --yes "Smoke test"
agentkodex session list
agentkodex session status last
agentkodex session attach last
agentkodex session send last "Run the tests now"
agentkodex session interrupt last
agentkodex session kill last
agentkodex session replay last
agentkodex session finalize last --gates lint,test,build --yes
```

`--wait` on `session start` waits for the agent process and then automatically runs configured gates/finalization. Use `--no-finalize` when you want to wait for exit but manually run gates later.

When a session is started with `--wait`, Agentkodex waits for the agent process to exit and then finalizes the run by executing discovered gates unless `--gates none` or `--no-finalize` is supplied.

## Cockpit UI

Start the local UI:

```bash
agentkodex cockpit --host 127.0.0.1 --port 3919
```

Cockpit provides:

- session list
- live transcript view
- send messages into a running session
- interrupt/kill controls
- pending approvals
- finalize controls
- JSON API endpoints for automation

Useful API endpoints:

```text
GET  /api/health
GET  /api/status
GET  /api/sessions
GET  /api/approvals
GET  /api/sessions/:id/transcript
GET  /api/sessions/:id/events
POST /api/sessions/:id/send
POST /api/sessions/:id/interrupt
POST /api/sessions/:id/kill
POST /api/sessions/:id/finalize
POST /api/approvals/:id/approve
POST /api/approvals/:id/deny
```

## Project memory

Agentkodex writes durable local memory under the target repo:

```text
.agentkodex/
  config.json
  project.kodex.md
  commands.kodex.json
  errors.kodex.json
  approvals.json
  runs/
  sessions/
  tournaments/
  prompts/
```

A Runtime v2 run stores:

```text
.agentkodex/runs/<run-id>/
  task-brief.yaml
  plan.md
  mission.prompt.md
  transcript.log
  session-events.ndjson
  commands.log
  policy.log
  gate-results.json
  qa-report.md
  security-report.md
  final-report.md
  diff.patch
```

## Supported adapters

| Adapter | Default executable/template | Notes |
|---|---|---|
| `local` | built-in | Plans, discovers, runs gates; does not edit code by itself. |
| `shell` | explicit `--command` | Useful for smoke tests and scripted workflows. |
| `codex` | `codex` | External Codex CLI on `PATH`. |
| `claude-code` | `claude` | External Claude Code CLI on `PATH`. |
| `aider` | `aider --message-file {promptFile}` | External Aider CLI. |
| `gemini` | `gemini` | External Gemini CLI. |
| `opencode` | `opencode` | External OpenCode CLI. |
| `cursor` | `cursor-agent` | External Cursor agent CLI. |
| `custom` | configured by user | Bring your own coding-agent command. |

Template variables:

```text
{promptFile} {prompt} {cwd} {runDir} {task}
```

## Tournament mode

```bash
agentkodex tournament \
  --agents codex,claude-code,aider \
  --mode sandbox_auto \
  --gates test,build \
  "Fix the failing auth tests"
```

Agentkodex copies the repo into isolated temp workspaces, runs each adapter, executes gates, and writes a tournament scorecard.

## Safety model

Modes:

- `observe`: refuses execution.
- `supervised`: safe commands run; unknown/risky commands require approval.
- `sandbox_auto`: broader command allowance for disposable workspaces.
- `trusted_auto`: broad local automation; destructive commands remain blocked.

Blocked by default:

- destructive `rm -rf /` style commands
- `sudo`
- broad permission changes
- credential-directory reads
- curl/wget pipe-to-shell
- production-looking dangerous operations

Approval-required examples:

- package installs
- Docker up/build/run
- git push/reset/clean/commit
- deploy commands
- migrations

## Development

Run the full test suite:

```bash
npm test
```

Run a local smoke test against the included sample project:

```bash
TMP=$(mktemp -d)
cp -R examples/sample-js/. "$TMP/"
node bin/agentkodex.js run --cwd "$TMP" --skip-agent --yes "Verify sample project"
node bin/agentkodex.js run --runtime cockpit --cwd "$TMP" --agent shell --command "node -e \"console.log('runtime ok')\"" --mode sandbox_auto --yes --wait "Runtime smoke"
```

## Current limitation

Agentkodex provides the harness, runtime, memory, approval, validation, and control plane. Intelligent code editing still comes from the external coding-agent CLI you choose. The included `shell` and `local` adapters are intentionally deterministic so the harness can be tested without paid agent credentials.
