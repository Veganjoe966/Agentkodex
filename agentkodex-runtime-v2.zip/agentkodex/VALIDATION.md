# Agentkodex v0.3.0 Validation Report

Validated on: 2026-06-03T04:21:34Z  
Runtime: Node.js v22.16.0  
Package: `agentkodex@0.3.0`

## Summary

Agentkodex v0.3.0 was validated as a working Node.js CLI package with Runtime v2 persistent sessions and a dependency-free local Cockpit UI/API.

Validation covered:

- CLI boot, help, and version commands
- syntax checks for all JavaScript files
- automated test suite
- project discovery
- policy and secret redaction
- one-shot run loop
- Runtime v2 session start/send/replay/finalize
- session gate execution
- approval queue listing
- Cockpit HTTP API
- `run --runtime cockpit` compatibility path

## Syntax check

Command:

```bash
find bin src tests -name '*.js' -print0 | xargs -0 -n1 node --check
```

Result:

```text
syntax check passed
```

## Automated tests

Command:

```bash
npm test
```

Result:

```text
1..21
# tests 21
# suites 0
# pass 21
# fail 0
# cancelled 0
# skipped 0
# todo 0
```

Covered areas:

- argument parsing and `--repo`/`--cwd` handling
- CLI help/version boot without missing imports
- Cockpit snapshot mode
- approval queue display
- Cockpit API health/sessions endpoints
- project discovery and gate selection
- command policy and blocked-command detection
- secret redaction
- one-shot Agentkodex runs
- compatibility daemon tests
- Runtime v2 per-session supervisor
- live input/send support
- transcript replay
- gate finalization
- command runner behavior

## Doctor command

Command:

```bash
node bin/agentkodex.js doctor
```

Key output:

```text
Agentkodex doctor
root: /mnt/data/agentkodex
node: v22.16.0
package: 0.3.0
runtime: Runtime v2 per-session supervisors
sessions: 0 total, 0 live
compat daemon: not running/not required
```

The local validation environment did not have third-party coding CLIs installed, so Codex, Claude Code, Aider, Gemini, OpenCode, Cursor, and custom agents reported as missing. That is expected. Agentkodex does not bundle those external agent binaries or credentials.

## One-shot gate validation

Command:

```bash
node bin/agentkodex.js run \
  --cwd examples/sample-js \
  --skip-agent \
  --gates lint,test,build \
  --yes \
  --quiet \
  "Validate sample project gates"

node bin/agentkodex.js status --cwd examples/sample-js
```

Result:

```text
Run: 20260603-042010-validate-sample-project-gates
Status: passed
Task: Validate sample project gates
Agent: local
Mode: supervised
Runtime: oneshot
```

## Persistent Runtime v2 session validation

Command:

```bash
node bin/agentkodex.js session start \
  --agent shell \
  --command 'printf "READY\n"; read line; printf "GOT:%s\n" "$line"' \
  --mode sandbox_auto \
  --yes \
  "interactive smoke"

node bin/agentkodex.js session send last hello
node bin/agentkodex.js session replay last
```

Expected transcript pattern:

```text
READY
GOT:hello
[exit 0]
```

This flow is also covered by automated tests.

## `run --runtime cockpit` smoke validation

Command:

```bash
TMP=$(mktemp -d)
cat > "$TMP/package.json" <<'JSON'
{"name":"ak-smoke","scripts":{"test":"node -e \"console.log('test pass')\"","build":"node -e \"console.log('build pass')\""}}
JSON

node bin/agentkodex.js init --repo "$TMP"
node bin/agentkodex.js run \
  --repo "$TMP" \
  --runtime cockpit \
  --agent shell \
  --command "node -e \"console.log('runtime run smoke')\"" \
  --mode sandbox_auto \
  --yes \
  --wait \
  --gates none \
  "Runtime run smoke"

node bin/agentkodex.js session gates --repo "$TMP" last --gates test,build --yes --quiet
node bin/agentkodex.js cockpit --repo "$TMP" --json
```

Result summary:

```text
Final status: completed/completed exit=0
Session gates complete:
- test: exit=0 command=npm run test
- build: exit=0 command=npm run build
Cockpit JSON root matched the temp project and reported one session.
```

## Cockpit HTTP API validation

Covered by `tests/cockpit.test.js`:

```text
GET /api/health  -> { ok: true, root: ... }
GET /api/sessions -> { sessions: [] }
```

The CLI also supports a non-server snapshot mode:

```bash
node bin/agentkodex.js cockpit --once
node bin/agentkodex.js cockpit --json
```

## Final status

```text
VALIDATED: PASS
```

Known boundary: Agentkodex is the harness, runtime, memory, approval, validation, and control plane. It controls external coding-agent CLIs when they are installed and authenticated, but it does not include proprietary agent binaries, accounts, API keys, or credentials.
