'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { discoverProject, selectCommands, parseMakeTargets } = require('../src/discovery');

test('discovers package scripts and npm package manager', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ak-discovery-'));
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({
    name: 'demo',
    scripts: { test: 'node --test', build: 'node build.js', lint: 'eslint .' },
    dependencies: { react: '^18.0.0', vite: '^5.0.0' }
  }, null, 2));
  const discovery = discoverProject(dir);
  assert.equal(discovery.projectName, 'demo');
  assert.equal(discovery.packageManager, 'npm');
  assert.ok(discovery.commands.some((cmd) => cmd.name === 'test' && cmd.command === 'npm run test'));
  assert.ok(discovery.frameworks.includes('react'));
  assert.ok(discovery.frameworks.includes('vite'));
  const gates = selectCommands(discovery, ['lint', 'test', 'build']);
  assert.deepEqual(gates.map((g) => g.gate), ['lint', 'test', 'build']);
});

test('parses Makefile targets', () => {
  const targets = parseMakeTargets('test:\n\tnode --test\n.PHONY: test\nbuild:\n\tnode build.js\n');
  assert.deepEqual(targets, ['test', 'build']);
});
